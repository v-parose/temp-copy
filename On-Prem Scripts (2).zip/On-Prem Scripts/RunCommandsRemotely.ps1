<#
.SYNOPSIS
Run commands on remote Linux/MacOS system(s)

.DESCRIPTION
Use this script to run commands or shell file on remote Linux/MacOS system(s).
Apply to following scenarios. 
Please run Get-Help RunCommandsRemotely -examples to view how to use this script for each scenario.
- Run commands on single system
- Run commands on multiple systems
- Run shell script file on single system
- Run shell script file on multiple systems

.EXAMPLE
- Run commands on single system
    .\RunCommandsRemotely.ps1 -HostIP 10.10.10.10 -CommandsToRun "cd Downloads;ls"

- Run commands on multiple systems
    .\RunCommandsRemotely.ps1 -PathForHostsFile .\TestUbuntu.ini -MultiHosts -CommandsToRun "cd Downloads;ls"

- Run shell script file on single system
    .\RunCommandsRemotely.ps1 -HostIP 10.10.10.10 -ScriptFilePathOnRemoteSystem Downloads/testBashScript.sh

- Run shell script file on multiple systems
    .\RunCommandsRemotely.ps1 -PathForHostsFile .\TestUbuntu.ini -MultiHosts -ScriptFilePathOnRemoteSystem Downloads/testBashScript.sh

.PARAMETER PathForHostsFile
Use this together with MultiHosts to specify the .ini file that contains the hosts information. There could be multiple sections in one file.
Example:
    [Section1]
    CPPMAC-ARM64-01		ansible_host=10.250.123.8
    CPPMAC-ARM64-02		ansible_host=10.250.123.6
    [Section2]    
    CPPMAC-ARM64-01		ansible_host=10.250.123.8
    CPPMAC-ARM64-02		ansible_host=10.250.123.6

.PARAMETER MultiHosts
Use this to indicate running commands on multiple systems.
Use together with PathForHostsFile

.PARAMETER HostIP
Use this to pass the system IP when you would like to run commands on.

.PARAMETER ScriptFilePathOnRemoteSystem
Use this to specify the path of the shell script on remote system(s).
If you have the script file on local system rather than remote system(s). You could copy it with script FileTransferForLinuxRemotely.ps1 at first.

.PARAMETER ScriptArguments
Use this to specify arguments for the shell script to run.
For argument without flag, use space to split the arguments. E.g., "arg1 arg2 arg3".
For argement with flag, add the flag as well. E.g., "-m arg1 -k arg2"

.PARAMETER CommandsToRun
Specify the commands you would like to run on remote system(s).
Use ";" to split multi commands. 
Example:
    Go to Downloads directory and check the files in it with following commands. It will list all the file(s) and dir(s) in Downloads directory.
    cd Downloads; ls
#>
param(       
    # Hosts to run commands  
    [Parameter(mandatory = $false)]
    [string]
    $PathForHostsFile,
    # Indicate whether to process multi hosts    
    [Parameter(Mandatory = $false)]
    [switch]
    $MultiHosts,
    # Host to run commands  
    [Parameter(mandatory = $false)]    
    [string]
    $HostIP,        
    # Path to a .sh file    
    [Parameter(mandatory = $false)]
    [string]
    $ScriptFilePathOnRemoteSystem,
    [Parameter(mandatory = $false)]
    [string]
    $ScriptArguments,
    # Command to run. For mulitple commands, please use ';' to separate    
    [Parameter(mandatory = $false)]
    [string]
    $CommandsToRun
)

$ErrorActionPreference = 'Stop'
$failToImportModule = "Failed to import module files. Please make sure you have the Modules folder with following module files in same directory with this script and try again.`n ConsoleModule.psm1 `n FileModule.psm1 `n ProcessAnsibleInventoryFileModule.psm1 `n AzureModule.psm1"
try {
    Import-Module -Name $PSScriptRoot'\Modules\ProcessAnsibleInventoryFileModule.psm1' -Force
    Import-Module -Name $PSScriptRoot'\Modules\FileModule.psm1' -Force
    Import-Module -Name $PSScriptRoot'\Modules\ConsoleModule.psm1' -Force
}
catch {
    Write-Host $failToImportModule -ForegroundColor Red
    return
}

<#
.SYNOPSIS
Check and install or prompt on missing required dependencies
#>
function Import-RequiredModules {
    # Check if Posh-SSH is installed
    Write-Log -LogToWrite "Checking if Posh-SSH module is installed..."
    $poshSSHModule = "Posh-SSH"
    $installed = Get-Module -ListAvailable -Name $poshSSHModule   

    if ($null -eq $installed) {
        # If not installed, install Posh-SSH        
        # Write-Host "Posh-SSH module does not exist. Installing..." -ForegroundColor Magenta
        Write-Log -LogToWrite "Posh-SSH module does not exist. Installing..."
        try {
            Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
            Install-Module Posh-SSH -Force
            Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force
            # Write-Host "Posh-SSH successfully installed." -ForegroundColor Green
            Write-Log -LogToWrite "Posh-SSH successfully installed."
        }
        catch {
            Write-Log -LogToWrite "Failed to install moduel Posh-SSH with error: $($_.Exception)"
            Write-Error "Failed to install moduel Posh-SSH with error: $($_.Exception)"
        }
       
    }

    Write-Log -LogToWrite "All required modules have been installed!`n"
}

<#
.SYNOPSIS
Create SSHSession and run command within the session.
#>
function Invoke-CommandOnRemoteSystem {
    param (
        $HostIP,
        $Commands
    )
       
    try {
        ## Create SSHSession        
        $Session = New-SSHSession -ComputerName $HostIP -Credential $Global:Cred -Force
        
        ## Run command
        if ($Session) {
            $results = Invoke-SSHCommand -SSHSession $Session -Command $Commands

            if ($results.ExitStatus -eq 0) {
                # Show outputs
                Write-Log -LogToWrite "  Commands ran succeeded on host(s) $HostIP!"
                Write-Host "  Commands ran succeeded on host(s) $HostIP!" -ForegroundColor Green
                Write-log -LogToWrite "  Outputs are: "
                Write-Host "  Outputs are: " -ForegroundColor Green    
                $results | ForEach-Object {
                    "   $($_.Host):     " | Write-Log
                    "               $($_.Output)" | Write-Log
                    "   $($_.Host):     " | Write-Host -ForegroundColor Green
                    "               $($_.Output)" | Write-Host -ForegroundColor Green
                }            
            }
            else {
                Throw $result.Error
            }  
        }
      
    }
    catch {
        Write-Log -LogToWrite "  Failed to run command against system $HostIP with Error: $_"
        Write-Error "Failed to run command against system $HostIP with Error: $($_.Exception.Message)" -ErrorAction Continue
    }
    finally {
        if ($Session) {
            Remove-SSHSession $Session | Out-Null
        }
    }    
}

Write-Log -LogToWrite "----------------------------Start Process for running commands remotely----------------------------"      
Write-Log -LogToWrite "-------------------------Pre-Checking-------------------------"
Import-RequiredModules
######################################################
# Check parameters to make sure they are set properly
######################################################
## Host(s) information
if (!($MultiHosts -and $PathForHostsFile) -and !($HostIP)) {
    $title = 'Would you like to run commands on multiple hosts?'
    $question = 'Yes for Multiple hosts, No for single host. Ctrl + C to cancel the process.'        
    $decision = Show-ConfirmMsg -Title $title -Content $question  
    if ($decision -eq 0) {
        $MultiHosts = $true            
        Write-Host "User would like to run commands on multiple hosts!" -ForegroundColor Green
        do {
            Write-Host "Please specify the path for a .ini file contains the hosts to process. Example: `n[VSM_XAM] `nVSM-XAM-10     ansible_host=10.218.200.24 `nVSM-XAM-11     ansible_host=10.218.200.26 `n" -ForegroundColor Cyan
            $PathForHostsFile = Read-Host "Enter the path for the .ini file contains hosts" 
        }while (!(Resolve-Path $PathForHostsFile -ErrorAction SilentlyContinue))      
        
        ## Prompt user to provide the credential to access the host(s) 
        Write-Host "Provide credential to connect to hosts" -ForegroundColor Cyan   
        $Global:cred = Get-CredentialFromInput -UserNameMsg "Enter user name for connecting to hosts" -PasswordMsg "Enter password for connecting to hosts"
    }
    else {
        $MultiHosts = $false
        Write-Host "User would like to run commands on single host!" -ForegroundColor Green
        do {
            do {                   
                $HostName = Read-Host "Enter the name for the host"
            }while (!$HostName.Trim())
            $HostName = $HostName.Trim()            
        
            do {                   
                $HostIP = Read-Host "Enter the IP address for the host"
            }while (!$HostIP.Trim())
            $HostIP = $HostIP.Trim()

            ## Prompt user to provide the credential to access the host(s)    
            $Global:cred = Get-CredentialFromInput -UserNameMsg "Enter user name for connecting to host $HostName"`
                -PasswordMsg "Enter password for connecting to host $HostName"
        }while (!(Test-HostIP -HostName $HostName -HostIP $HostIP -Credential $Global:cred))
    }
}

## Commands or Shell script to run
$title = 'Would you like to run commands or a shell script on remote system?'
$question = 'Yes for typing commands directly, No for providing the path for the shell script on remote system. Ctrl + C to cancel the process.'        
$decision = Show-ConfirmMsg -Title $title -Content $question
if ($decision -eq 0) {
    Write-Host "User would like to input the commands to run directly." -ForegroundColor Green
    Write-Host "Please enter the commands you would like to run. Use ';' to split multi commands. `n`
    For example, use following commands to list the files under Downloads directory: `n `
    cd Downloads; ls -l" -ForegroundColor Cyan
    $CommandsToRun = Read-Host "Enter the commands to run"
}
else {
    Write-Host "User would like to run shell script on the remote system." -ForegroundColor Green
    Write-Host "Please enter the path for the shell script on the remote system." -ForegroundColor Cyan
    $ScriptFilePathOnRemoteSystem = Read-Host "Enter the path for the shell script on remote system"
    $ScriptArguments = Read-Host "Enter the arguments (Press Enter directly if no argument needed)"
}


####################################################################################
# Start process
####################################################################################

try {     
    #Get the commands to run
    if ($ScriptFilePathOnRemoteSystem) {
        $Commands = "bash $ScriptFilePathOnRemoteSystem $ScriptArguments"    
    }
    else {
        $Commands = $CommandsToRun
    }
    Write-Log -LogToWrite "-------------------------Running Command on Host(s)-------------------------"
    #Get the host(s) to run against 
    if ($MultiHosts) {
        ################################################################################
        # Process with multiple hosts
        ################################################################################  
   
        $hosts = Get-HostsToProcess -PathForHostsFile $PathForHostsFile

        # Print out the hosts list for user to confirm
        Write-Log -LogToWrite "Hosts retrieved from inventory file:"
        foreach ($key in $hosts.Keys) {            
            Write-Log -LogToWrite "    Found $($($($hosts.Item($key)).Keys).Count) hosts for $key"
            Write-Host "Found $($($($hosts.Item($key)).Keys).Count) hosts for $key" -ForegroundColor Green
        }

        $title = 'Confirm to process hosts'
        $question = 'Would you like to continue to process the hosts?'        
        $decision = Show-ConfirmMsg -Title $title -Content $question  

        if ($decision -eq 0) { 
            Write-Log -LogToWrite "User would like to continue processing these hosts."          

            foreach ($key in $hosts.Keys) {
                Write-Log -LogToWrite "  ---------------Processing hosts for $key---------------"
                Write-Host "`n--------------Procession hosts for $key--------------`n" -ForegroundColor Cyan
                $hostsForSection = $hosts.Item($key)

                $hostNames = $hostsForSection.Keys
                if ($hostNames.Count -gt 0) {
                    $hostIPs = [Collections.Generic.List[String]][string[]]$hostsForSection.Values
                    
                    # Verify to make sure host name and host IP match
                    $hostNames | ForEach-Object {
                        $hostIP = $hostsForSection.Item($_)
                        $rel = Test-HostIP -HostName $_ -HostIP $HostIP -Credential $Global:cred
                        if ($rel -eq $false) {
                            $hostIPs.Remove($hostIP) | Out-Null
                            Write-Host "The host name of $hostIP does not match $_. Skipped." -ForegroundColor Red
                            Write-Log "The host name of $hostIP does not match $_. Skipped."
                        }
                        elseif (!$rel) {
                            $hostIPs.Remove($hostIP) | Out-Null
                        }
                    }
                    if ($hostIPs.Count -gt 0) {
                        $hostIPs = $hostIPs.ToArray()
                        Write-Log -LogToWrite "  Running commands on hosts $hostIPs"
                        Write-Host "  Running commands on $hostIPs" -ForegroundColor Cyan
                        Invoke-CommandOnRemoteSystem -HostIP $hostIPs -Commands $Commands
                    }
                }   
            }           
        }    
    }
    else {
        #################################################################################
        # Process with single host
        #################################################################################
        Write-Log -LogToWrite "-------------------------Processing Host $HostIP-------------------------"
        Write-Log -LogToWrite "  Running commands on host $HostIP"
        Write-Host "Running commands on $HostIP" -ForegroundColor Cyan

        Invoke-CommandOnRemoteSystem -HostIP $HostIP -Commands $Commands
    }
}
catch {
    Write-Log -LogToWrite "Script failed with error: $_"
    Write-Error "Script failed with error: $_"
}