<#
.SYNOPSIS
Update password for specified user account

.DESCRIPTION
Update the password for the specified user account on remote system if the user exist.

.PARAMETER PathForHostsFile
Use this together with MultiHosts to specify the .ini file that contains the hosts information. There could be multiple sections in one file.
Example:
    [Section1]
    CPPMAC-ARM64-01		ansible_host=10.250.123.8
    CPPMAC-ARM64-02		ansible_host=10.250.123.6
    [Section2]    
    CPPMAC-ARM64-01		ansible_host=10.250.123.8
    CPPMAC-ARM64-02		ansible_host=10.250.123.6

.PARAMETER MultiHosts
Use this to indicate running commands on multiple systems.
Use together with PathForHostsFile

.PARAMETER HostIP
Use this to pass the system IP when you would like to run commands on.

.PARAMETER UserName
Name of the user account to rotate password

.PARAMETER VaultName
Name of the Vault to store password for host(s). Ignore if no need to store. 
Script will prompt for user to sign in to access the Vault. Please make sure you have access to the KV when run this script.
#>

param(       
    # Hosts to crate account 
    [Parameter(mandatory = $false)]
    [string]
    $PathForHostsFile,
    # Indicate whether to process multi hosts    
    [Parameter(Mandatory = $false)]
    [switch]
    $MultiHosts,
    # Host to create account  
    [Parameter(Mandatory = $false)]    
    [string]
    $HostIP,
    [Parameter(Mandatory = $false)]
    [string]
    $UserName,
    [parameter(Mandatory = $false)]
    [string]
    $VaultName
)

$ErrorActionPreference = 'Stop'
$failToImportModule = "Failed to import module files. Please make sure you have the Modules folder with following module files in same directory with this script and try again.`n ConsoleModule.psm1 `n FileModule.psm1 `n ProcessAnsibleInventoryFileModule.psm1 `n AzureModule.psm1"
try {
    Import-Module -Name $PSScriptRoot'\Modules\ProcessAnsibleInventoryFileModule.psm1' -Force
    Import-Module -Name $PSScriptRoot'\Modules\FileModule.psm1' -Force
    Import-Module -Name $PSScriptRoot'\Modules\ConsoleModule.psm1' -Force
    Import-Module -Name $PSScriptRoot'\Modules\AzureModule.psm1' -Force
}
catch {
    Write-Host $failToImportModule -ForegroundColor Red
    return
}

<#
.SYNOPSIS
Check and install or prompt on missing required dependencies
#>
function Import-RequiredModules {
    # Check if Posh-SSH is installed
    Write-Log -LogToWrite "Checking if Posh-SSH module is installed..."
    $poshSSHModule = "Posh-SSH"
    $installed = Get-Module -ListAvailable -Name $poshSSHModule   

    if ($null -eq $installed) {
        # If not installed, install Posh-SSH        
        # Write-Host "Posh-SSH module does not exist. Installing..." -ForegroundColor Magenta
        Write-Log -LogToWrite "Posh-SSH module does not exist. Installing..."
        try {
            Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
            Install-Module Posh-SSH -Force
            Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force
            # Write-Host "Posh-SSH successfully installed." -ForegroundColor Green
            Write-Log -LogToWrite "Posh-SSH successfully installed."
        }
        catch {
            Write-Log -LogToWrite "Failed to install moduel Posh-SSH with error: $($_.Exception)"
            Write-Error "Failed to install moduel Posh-SSH with error: $($_.Exception)"
        }
       
    }

    Write-Log -LogToWrite "All required modules have been installed!`n"
}

<#
.SYNOPSIS
Restart single system
#>
function Restart-System {
    Param(
        $HostIP
    )

    try {
        # Create SSHSession to run command remotely
        $session = New-SSHSession -ComputerName $HostIP -Credential $Global:Credential -Force
        $command = "sudo shutdown -r now"
        $result = Invoke-SSHCommand -SSHSession $session -Command $command

        ## Check result     
        if (($result.ExitStatus -eq 1) -and ($result.Error -like "*sudo: a password is required*")) {
            ## Failed to run the command due to sudo requires password per the the system configuration
            ## Pipeline admin password and try again
            try {
                $adminPwdStr = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($($Global:Credential).Password))
                $command = "echo $adminPwdStr | sudo -S shutdown -r now"           
                $rel = Invoke-SSHCommand -SSHSession $session -Command $command
            }
            catch {
                ## The connection will lost once system is reboot
                ## We capture this exception and treat this as successfully reboot
                if ($_.Exception -like "*An established connection was aborted by the server.*") {
                    Write-Host "System $($result.Host) has been successfully sent to reboot." -ForegroundColor Green
                    Write-Log "System $($result.Host) has been successfully sent to reboot." 
                }                
            }
            finally {
                if ($adminPwdStr) {
                    Remove-Variable adminPwdStr
                }
            }
        }
        elseif ($result.ExitStatus -ne 0) {
            Write-Host "Failed to reboot $($result.Host) with error $($result.Error)" -ForegroundColor Red
            Write-Log -LogToWrite "Failed to reboot $($result.Host) with error $($result.Error)"            
        }   
    }
    catch {
        ## The connection will lost once system is reboot
        ## We capture this exception and treat this as successfully reboot
        if ($_.Exception -like "*An established connection was aborted by the server.*") {
            Write-Host "System $HostIP has been successfully sent to reboot." -ForegroundColor Green
            Write-Log "System $HostIP has been successfully sent to reboot."                                   
        }
    }
    finally {
        if ($session) {
            Remove-SSHSession $session | Out-Null
        }       
    }
}

<#
.SYNOPSIS
Generate password with provided length with at least one digit, capital letter
Password is return in Secure string format
#>
function New-Password {
    param(
        [int]$Length
    )
    $chars = "23456789ABCDEFGHJKLMNPRSTUVWXYZabcdefghijkmnopqrstuvwxyz"    
    $caps = "ABCDEFGHJKLMNPRSTUVWXYZ"
    $digits = "23456789"
      
    $password = ""
    # At lease one digit, one capital letter
    $password += Get-Random -InputObject $digits.ToCharArray()
    $password += Get-Random -InputObject $caps.ToCharArray()    

    $leftCount = $Length - 2
    $password += -Join (Get-Random -InputObject $chars.ToCharArray() -Count $leftCount)

    ## Shuffle the result
    $fiPassword = -Join (Get-Random -InputObject $password.ToCharArray() -Count $Length)
    $securePassword = ConvertTo-SecureString $fiPassword -AsPlainText -Force

    return $securePassword
}

<#
.SYNOPSIS
Store/update the password to Azure KeyVault with host name as the secret name
#>
function Update-PasswordToAzure {
    param(
        [string]$HostName,
        [string]$VaultName,
        [securestring]$Password
    )
   
    if (Set-AzureSecret -KeyVault $VaultName -SecretName $HostName -SecretValue $Password) {
        Write-log -LogToWrite "Successfully update password for $HostName to Azure."
        Write-Host "Successfully update password for $HostName to Azure." -ForegroundColor Green         
    }
    else {
        Write-Log -LogToWrite "Error: Failed to update password for $HostName to Azure. Please try again later."
        Write-Host "Error: Failed to update password for $HostName to Azure. Please try again later." -ForegroundColor Red
    }
}

<#
.SYNOPSIS
Check if the remote path exist, if not create the path
Return the hosts have path created
#>
function Resolve-RemotePath {
    Param(
        $HostIP,
        $Path
    )
   
    $succeededHosts = [System.Collections.ArrayList]@()   

    $HostIP | ForEach-Object { $succeededHosts.Add($_) | Out-Null }

    try {
        # Create SSHSession to run command remotely
        $session = New-SSHSession -ComputerName $HostIP -Credential $Global:Credential -Force
        $command = "mkdir -p $Path"
        $result = Invoke-SSHCommand -SSHSession $session -Command $command

        # Verify all hosts return 0
        $result | ForEach-Object {
            if ($_.ExitStatus -ne 0) {
                Write-Host "Failed to resolve path $Path on host $($_.Host) with error $($_.Error)" -ForegroundColor Red
                $succeededHosts.Remove($($_.Host)) | Out-Null
            }            
        }

        return $succeededHosts
    }
    catch {
        Write-Host "Failed to resolve the path $Path on remote systems with error $($_.Exception)" -ForegroundColor Red
        return $null
    }
    finally {
        if ($session) {
            Remove-SSHSession $session | Out-Null
        }
    }
}

<#
.SYNOPSIS
Create a new user account with the script "On-Prem Scripts\CreateUserAccount.sh"
#>
function Update-UserPassword {
    param(
        [Parameter(Mandatory = $true)]
        [string]
        $HostIP,
        [Parameter(Mandatory = $true)]
        [string]
        $UserName,
        [Parameter(Mandatory = $true)]
        [securestring]
        $NewPassword
    )

    try {
        ## copy script file to remote, then run script as sudo
        ## Copy https://stackoverflow.com/questions/73488837/windows-powershell-posh-ssh-module-script-sftp-file-upload-to-linux-server-givin
        $scriptPath = "UpdateUserPassword.sh"
        $scriptFullPath = Resolve-Path $scriptPath
        $targetPath = "temp"

        $HostsHavePathResolved = Resolve-RemotePath $HostIP $targetPath
        if ($HostsHavePathResolved) {
            # Upload script to remote host
            $CopyScriptSession = New-SFTPSession -ComputerName $HostsHavePathResolved -Credential $Global:Credential -Force
            if ($CopyScriptSession) {
                Set-SFTPItem -SFTPSession $CopyScriptSession -Path  $scriptFullPath -Destination $targetPath -Force

                ## Create SSHSession for running create user script     
                $session = New-SSHSession -ComputerName $HostIP -Credential $Global:Credential -Force
                
                if ($session) {
                    $passwordStr = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($NewPassword))
                    $adminPwdStr = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($($Global:Credential).Password))
                    ## Change file mode to allow execute and Run command
                    $command = "chmod +x $targetPath/$scriptPath ; vim $targetPath/$scriptPath -c 'set ff=unix' -c ':wq'; sudo $targetPath/$scriptPath -u $UserName -p $passwordStr -m $(($Global:Credential).UserName) -t $adminPwdStr"
                    
                    try {
                        $result = Invoke-SSHCommand -SSHSession $session -Command $command                    
                        $result | ForEach-Object {
                            if (($result.ExitStatus -eq 1) -and ($result.Error -like "*sudo: a password is required*")) {
                                ## Failed to run the command due to sudo requires password per the the system configuration
                                ## Pipeline admin password and try again
                                $command = "chmod +x $targetPath/$scriptPath ; vim $targetPath/$scriptPath -c 'set ff=unix' -c ':wq'; echo $adminPwdStr | sudo -S $targetPath/$scriptPath -u $UserName -p $passwordStr -m $(($Global:Credential).UserName) -t $adminPwdStr"
                                $rel = Invoke-SSHCommand -SSHSession $session -Command $command
                                if ($rel.ExitStatus -eq 0) {
                                    Write-Host "Successfully updated password for user $UserName on host $($_.Host).`n" -ForegroundColor Green
                                    Write-log -LogToWrite "Successfully updated password for user $UserName on host $($_.Host).`n"

                                    ## Reboot system 
                                    Write-Host "Reboot System $($_.Host) to let the new password take effect" -ForegroundColor Cyan
                                    Write-Log -LogToWrite "Reboot System $($_.Host) to let the new password take effect"
                                    Restart-System -HostIP $_.Host
                                }
                                else {
                                    Write-Host "Failed to update password for $UserName on host $($_.Host) with error $($_.Error)`n" -ForegroundColor Red
                                    Write-log -LogToWrite "Failed to update password for $UserName on host $($_.Host) with error $($_.Error)`n"
                                }
                            }                            
                            elseif (($_.ExitStatus -eq 0) -and ($_.Output -eq "succeeded")) {
                                Write-Host "Successfully updated password for user $UserName on host $($_.Host).`n" -ForegroundColor Green
                                Write-log -LogToWrite "Successfully updated password for user $UserName on host $($_.Host).`n"

                                ## Reboot system to let the new password takes effect
                                Write-Host "Reboot System $($_.Host) to let the new password take effect" -ForegroundColor Cyan
                                Write-Log -LogToWrite "Reboot System $($_.Host) to let the new password take effect"
                                Restart-System -HostIP $_.Host
                            }
                            elseif (($_.ExitStatus -eq 0) -and ($_.Output -ne "succeeded")) {
                                Write-Host "Failed to update password for $UserName on host $($_.Host) with error '$($_.Output)'`n" -ForegroundColor Red
                                Write-log -LogToWrite "Failed to update password for $UserName on host $($_.Host) with error '$($_.Output)'`n"
                            }
                            elseif ($_.ExitStatus -ne 0) {
                                Write-Host "Failed to update password for $UserName on host $($_.Host) with error $($_.Error)`n" -ForegroundColor Red
                                Write-log -LogToWrite "Failed to update password for $UserName on host $($_.Host) with error $($_.Error)`n"
                            }
                        }
                    }
                    catch {
                        Write-Host "Failed to update password with error $($_.Exception)`n" -ForegroundColor Red
                        Write-log -LogToWrite "Failed to update password with error $($_.Exception)`n"
                    }
                }
            }
        }
        else {
            Write-log -LogToWrite "Failed to update password for $UserName due to could not copy script file to remote system(s)."
            Write-Error "Failed to update password for $UserName due to could not copy script file to remote system(s)." -ErrorAction Stop
        }
    }
    catch {
        Write-log -LogToWrite "Failed to update password for $UserName due to error $($_.Exception)"
        Write-Error "Failed to update password for $UserName due to error $($_.Exception)" -ErrorAction Stop
    }
    finally {
        if ($CopyScriptSession) {
            Remove-SFTPSession $CopyScriptSession | Out-Null
        }
        if ($session) {
            Remove-SSHSession $session | Out-Null
        }
        if ($passwordStr) {
            Remove-Variable passwordStr
        }
        if ($adminPwdStr) {
            Remove-Variable adminPwdStr
        }        
    }
}

try {    
    Write-Log -LogToWrite "`n---------------Start the process for updating password ---------------`n"
    Write-Log -LogToWrite "-------------------------Pre-Checking-------------------------"
    Import-RequiredModules
    ######################################################
    # Check parameters to make sure they are set properly
    ######################################################
    ## Host(s) information
    if (!($MultiHosts -and $PathForHostsFile) -and !($HostIP)) {
        Write-Log -LogToWrite "Get the host(s) to process"
        $title = 'Would you like to update password for multiple hosts?'
        $question = 'Yes for Multiple hosts, No for single host. Ctrl + C to cancel the process.'        
        $decision = Show-ConfirmMsg -Title $title -Content $question  
        if ($decision -eq 0) {
            $MultiHosts = $true            
            Write-Host "User would like to update password for multiple hosts!" -ForegroundColor Green
            do {
                Write-Host "Please specify the path for a .ini file contains the hosts to process. Example: `n[VSM_XAM] `nVSM-XAM-10     ansible_host=10.218.200.24 `nVSM-XAM-11     ansible_host=10.218.200.26 `n" -ForegroundColor Cyan
                $PathForHostsFile = Read-Host "Enter the path for the .ini file contains hosts" 
            }while (!(Resolve-Path $PathForHostsFile -ErrorAction SilentlyContinue))  
            
            ## Prompt user to provide the credential to access the host(s) 
            Write-Host "Provide credential to connect to hosts" -ForegroundColor Cyan   
            $Global:Credential = Get-CredentialFromInput -UserNameMsg "Enter user name for connecting to hosts" -PasswordMsg "Enter password for connecting to hosts"
        }
        else {
            $MultiHosts = $false
            Write-Host "User would like to update password for single host!" -ForegroundColor Green
            do {
                do {                   
                    $HostName = Read-Host "Enter the name for the host"
                }while (!$HostName.Trim())
                $HostName = $HostName.Trim()            
            
                do {                   
                    $HostIP = Read-Host "Enter the IP address for the host"
                }while (!$HostIP.Trim())
                $HostIP = $HostIP.Trim()

                ## Prompt user to provide the credential to access the host(s)    
                $Global:Credential = Get-CredentialFromInput -UserNameMsg "Enter user name for connecting to host $HostName"`
                    -PasswordMsg "Enter password for connecting to host $HostName"
            }while (!(Test-HostIP -HostName $HostName -HostIP $HostIP -Credential $Global:Credential))
        }
    }

    do {
        Write-Log -LogToWrite "Trying to get name of the user account."    
        $UserName = Read-Host "Enter the name of the User to update"    
    }while (!$UserName.Trim())

    Write-Log -LogToWrite "Name of the user account is $UserName"       
    
    ## Prompt for user to type and confirm password 
    $title = 'Would you like to let the script generate password for each host or enter one password for all?'
    $question = 'Yes for generating password. No for enter password manually. Ctrl + C to cancel the process.'        
    $decision = Show-ConfirmMsg -Title $title -Content $question
    if ($decision -eq 0) {
        Write-Log -LogToWrite "The script will generate password for each host"
        Write-Host "The script will generate password for each host" -ForegroundColor Cyan        
    }  
    else {
        Write-Log -LogToWrite "User choose to enter password manually"
        do {    
            $ManualPassword = Read-Host "Enter the password for the user" -AsSecureString
            $ConfirmPwd = Read-Host "Retype to confirm the password" -AsSecureString
            $PasswordStr = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($ManualPassword))
            $ConfirmPwdStr = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($ConfirmPwd))
        }
        while ($PasswordStr -ne $ConfirmPwdStr)

        if ($PasswordStr) { Remove-Variable PasswordStr }
        if ($ConfirmPwdStr) { Remove-Variable ConfirmPwdStr }
        if ($ConfirmPwd) { Remove-Variable ConfirmPwd } 
    }  

    ## Signin to Azure so we could use this to update keyvault    
    Write-Host "Provide the Vault name to store the password for the new user account for host(s)" -ForegroundColor Cyan
    $VaultName = Read-Host "Enter the Vault name (Press Enter directly if no need to store the password)"
    # Trim the spaces in case user copys extra spaces from web UI
    $VaultName = $VaultName.Trim()
    if ($VaultName) {
        Write-Host "Login to Azure to provide permission to update new password to Azure KeyVault $VaultName" -ForegroundColor Cyan
        Connect-AzAccount -DeviceCode | Out-Null
    }  

    #####################################################################
    ## Start process
    #####################################################################
    if ($MultiHosts) {
        ################################################################################
        # Process with multiple hosts
        ################################################################################  
        Write-Log -LogToWrite "Processing multi hosts."    
        $hosts = Get-HostsToProcess -PathForHostsFile $PathForHostsFile

        # Print out the hosts list for user to confirm
        Write-Log -LogToWrite "Hosts retrieved from inventory file:"
        foreach ($key in $hosts.Keys) {            
            Write-Log -LogToWrite "    Found $($($($hosts.Item($key)).Keys).Count) hosts for $key"
            Write-Host "Found $($($($hosts.Item($key)).Keys).Count) hosts for $key" -ForegroundColor Green
        }

        $title = 'Confirm to process hosts'
        $question = 'Would you like to continue to process the hosts?'        
        $decision = Show-ConfirmMsg -Title $title -Content $question
        if ($decision -eq 0) {
            Write-Host "User would like to continue the process" -ForegroundColor Green

            foreach ($key in $hosts.Keys) {
                Write-Log -LogToWrite "  ---------------Processing hosts for $key---------------"
                Write-Host "`n--------------Procession hosts for $key--------------`n" -ForegroundColor Cyan
                $hostsForSection = $hosts.Item($key)

                $hostNames = $hostsForSection.Keys
                if ($hostNames.Count -gt 0) {
                    foreach ($hostName in $hostNames) {
                        # Process each host
                        $hostIP = $hostsForSection.Item($hostName)
                        
                        # Verify to make sure the host name and host IP match
                        $rel = Test-HostIP -HostName $HostName -HostIP $HostIP -Credential $Global:Credential
                        if ($rel) {

                            Write-Log -LogToWrite "Updating password for $UserName for $hostName ($hostIP)"
                            Write-Host "-----Updating password for $UserName for $hostName ($hostIP)-----" -ForegroundColor Cyan
                        
                            if ($ManualPassword) {
                                $password = $ManualPassword                           
                            }
                            else {
                                # Generate password for the host
                                $password = New-Password -Length 12
                            }
                            # Create user with the generated password                        
                            Update-UserPassword -HostIP $hostIP -UserName $UserName -NewPassword $Password 

                            if ($VaultName) {
                                # Save the password to KeyVault
                                Update-PasswordToAzure -HostName $hostName -VaultName $VaultName -Password $password
                            }
                            Write-Log -LogToWrite "Completed password updating for $hostName ($hostIP)`n"
                        }
                        elseif ($rel -eq $false) {
                            Write-Log -LogToWrite "The host name and IP for $HostName do not match. Skipped."
                            Write-Host "The host name and IP for $HostName do not match. Skipped." -ForegroundColor Red
                        }
                    }
                }   
            }  
        }  
    }
    else {
        ################################################################################
        # Process single host
        ################################################################################ 
        Write-Log -LogToWrite "-------------------------------Processing host $HostName($HostIP)-------------------------------"
        Write-Log -LogToWrite "Updating password for $UserName for $HostName($HostIP)"
        Write-Host "  Updating password for $UserName for $HostName($HostIP)" -ForegroundColor Cyan
        if ($ManualPassword) {
            $password = $ManualPassword                           
        }
        else {
            # Generate password for the host
            $password = New-Password -Length 12
        }

        Update-UserPassword -HostIP $HostIP -UserName $UserName -NewPassword $password        

        if ($VaultName) {
            # Save the password to KeyVault
            Update-PasswordToAzure -HostName $HostName -VaultName $VaultName -Password $password
        }  
        
        Write-Log -LogToWrite "Completed password updating."
    }
}
catch {
    Write-Error "Script failed with error: $($_.Exception)"
}