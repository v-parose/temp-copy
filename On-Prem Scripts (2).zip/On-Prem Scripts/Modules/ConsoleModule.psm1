$ErrorActionPreference = 'Stop'
<#
.SYNOPSIS
Show user confirmation message, and return user's choice.
#>
function Show-ConfirmMsg {
    param (
        $Title,
        $Content
    )
    
    $choices = '&Yes', '&No'

    $result = $Host.UI.PromptForChoice($Title, $Content, $choices, 1)
    return $result
}

<#
.SYNOPSIS
Provide workaround to read credential from console
#>
function Get-CredentialFromInput {
    param(
        $UserNameMsg,
        $PasswordMsg
    )    

    do{
        $accountName = Read-Host "$UserNameMsg"
    }while(!$accountName.Trim())
    do{
        $accountPwd = Read-Host "$PasswordMsg" -AsSecureString
        $accountPwdTxt = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($accountPwd))
    }while(!$accountPwdTxt.Trim())
    Remove-Variable accountPwdTxt
    $Credential = [PSCredential]::New($accountName,$accountPwd)

    return $Credential    
}