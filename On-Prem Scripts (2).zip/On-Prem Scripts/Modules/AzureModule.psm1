$ErrorActionPreference = 'Stop'
<#
.SYNOPSIS
Make sure the system has Az PowerShell module installed
#>
function Install-AzModule {
    if (!(Get-Module -Name Az -ListAvailable)) {
        Write-Log -LogToWrite "  Az module is not installed. Installing..."
        Set-PSRepository -Name PSGallery -InstallationPolicy Trusted
        Install-Module -Name Az -AllowClobber -Scope CurrentUser
        Write-Log -LogToWrite "  Az module is successfully installed."
    }
    # Check if AzureRM module installed, if installed, uninstall it
    if (Get-Module -Name AzureRM -ListAvailable) {
        # Uninstall        
        Uninstall-AzureRm
    }    
}


<#
.SYNOPSIS
Read secret from Azure KeyVault and return in plain text
#>
function Get-AzureSecret {
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $KeyVault,
        [Parameter(Mandatory = $true)]
        [string]
        $Secret
    )
    try {
        Write-Log -LogToWrite "Trying to get secret $Secret from $KeyVault ..."
        Install-AzModule   | Out-Null     

        # Store the current context
        $currentContext = Get-AzContext        

        # Sign in to Azure if context is not available
        if (!$currentContext) {
            $null = Connect-AzAccount -DeviceCode | Out-Null
        }     

        # Get the secrete value
        $secretValue = Get-AzKeyVaultSecret -VaultName $KeyVault -Name $Secret -AsPlainText
        if ($secretValue) {
            Write-Log -LogToWrite "Value of $Secret retrieved succeeded!"
            return $secretValue
        }
        else {
            Write-Log -LogToWrite "Failed to retrieve value of $Secret."
            Write-Host "Failed to retrieve value of $Secret." -ForegroundColor Red
        }
    }
    catch {
        Write-Host "Failed to read secret from KV $KeyVault with error: $_." -ForegroundColor Red
        return $null
    }  
    finally {
        # Restore the previous context if available
        if ($currentContext) {
            Set-AzContext -Context $currentContext | Out-Null
        }
        else {
            Disconnect-AzAccount | Out-Null
        }
    }  
}

<#
.SYNOPSIS
Set secret to Azure
#>
function Set-AzureSecret {
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $KeyVault,
        [Parameter(Mandatory = $true)]
        [string]
        $SecretName,
        [Parameter(Mandatory = $true)]
        [securestring]
        $SecretValue
    )

    try {
        Write-Log -LogToWrite "Trying to set secret vaule for $SecretName in vault $KeyVault ..."
        Install-AzModule  | Out-Null     

        # Store the current context
        $currentContext = Get-AzContext        

        # Sign in to Azure if context is not available
        if (!$currentContext) {
            $null = Connect-AzAccount -DeviceCode | Out-Null
        }     

        # Set the secret value
        $secret = Set-AzKeyVaultSecret -VaultName $KeyVault -Name $SecretName -SecretValue $SecretValue

        if ($Secret) {
            Write-Host "Successfully set secret for $SecretName in vault $KeyVault" -ForegroundColor Green
            return $true
        }
        else {
            Write-Host "Failed to set secret for $SecretName in vault $KeyVault" -ForegroundColor Green
            return $false
        }
    }
    catch {
        Write-Host "Failed to set secret for $SecretName in vault $KeyVault with error: $($_.Exception)." -ForegroundColor Red
        return $false
    }  
    finally {
        # Restore the previous context if available
        if ($currentContext) {
            Set-AzContext -Context $currentContext | Out-Null
        }
        else {
            Disconnect-AzAccount | Out-Null
        }
    }  
}