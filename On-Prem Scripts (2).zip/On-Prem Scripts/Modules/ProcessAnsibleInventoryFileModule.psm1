Import-Module -Name $PSScriptRoot'\FileModule.psm1' -Force

$ErrorActionPreference = 'Stop'
<#
.SYNOPSIS
Read ini file content to hashtable
#>
function Get-IniContent {
    param($filePath)

    try {
        $ini = @{}

        ## If the file has no section, use the default section
        $section = "Machine"
        $ini[$section] = @{}
        switch -regex -file $FilePath {
            "^\[(.+)\]" {
                # Section
                $section = $matches[1]
                $ini[$section] = @{}
                $CommentCount = 0
            }
            "^(;.*)$" {
                # Comment
                $value = $matches[1]
                $CommentCount = $CommentCount + 1
                $name = "Comment" + $CommentCount               
                $ini[$section][$name] = $value
            }
            "(.+?)\s*=(.*)" {
                # Key
                $name, $value = $matches[1..2]
                $name = $name -replace "\s*ansible_host" # Read the ansible inventory file directly               
                $ini[$section][$name] = $value
            }        
        }
    
        return $ini
    }
    catch {
        Write-Host "Failed to read content from the file. " -ForegroundColor Red
        return $null
    }
    
}

<#
.SYNOPSIS
Read the host information from the provided file
#>
function Get-HostsToProcess { 
    param($PathForHostsFile)   
    # Check file extension to make sure we are processing .ini file
    $extension = [IO.Path]::GetExtension($PathForHostsFile)   
    if ($extension -eq ".ini") {
        
        $Content = Get-IniContent($PathForHostsFile)
        
        if ($Content) {
            return $Content
        }
        else {
            Write-Error "Failed to read host information from the ini file. Please double check to make sure the file has correct format and try again."
        }
    }
    else {
        Write-Log -LogToWrite "The inventory file is not in .ini format. Exit."
        Write-Error "Please provie an .ini file for host servers."
    }    
}

<#
.SYNOPSIS
Verify if the Host name and IP are match
#>
function Test-HostIP {
    param(
        [string]$HostName,
        [string]$HostIP,
        [pscredential]$Credential
    )

    if ($HostName -and $HostIP) {
        try {
            $session = New-SSHSession -ComputerName $HostIP -Credential $Credential -Force

            if ($session) {
                $command = "hostname"
                $result = Invoke-SSHCommand -SSHSession $session -Command $command 

                if ($result.ExitStatus -eq 0) {
                    if ($HostName.Trim() -eq $($result.Output).Trim()) {
                        return $true
                    }
                    else {
                        Write-Host "The host name for IP $HostIP is $($result.Output), which does not match your input host name $HostName." -ForegroundColor Red
                        return $false
                    }
                }
                else {
                    Write-Host "Failed to validate the host name and IP with error: $($result.Error)" -ForegroundColor Red
                }
            }
        }
        catch {
            if ($_.Exception -like "*Permission denied*") {
                Write-Host "The credential provided for connecting the host $HostIP is invalid." -ForegroundColor Red
            }
            else {
                Write-Host "Failed to validate the host name $HostName and IP $HostIP with error: $($_.Exception.Message)" -ForegroundColor Red
            }            
        }
        finally {
            if ($session) {
                Remove-SSHSession $session | Out-Null
            }
        }
    }
    else {
        Write-Host "Either host name $HostName or host IP $HostIP is null or empty" -ForegroundColor Red
    }        
}