$ErrorActionPreference = 'Stop'
<#
.SYNOPSIS
Write logs to local log file
#>
function Write-Log {
    param (
        [Parameter(Mandatory = $true,
            ValueFromPipeline = $true,
            ValueFromPipelineByPropertyName = $true)]
        [string]
        $LogToWrite,
        [Parameter(Mandatory = $false)]
        [string]
        $LogFilePath
    )
    # Point to the directory with the script excecuting, which is parent dir of the Modules
    $parentDirectory = Split-Path -Path $PSScriptRoot -Parent    
    $defaultPath = "$parentDirectory\Log_$($(Get-Date).ToString("yyyy_MM_dd")).log"
    # Check if log file path is passed. If not, use the default path
    if (!$LogFilePath) {
        $LogFilePath = $defaultPath
    }
   
    # If log file does not exist. Create the file
    if (!(Test-Path $LogFilePath)) {
        New-Item -Path $LogFilePath -Force | Out-Null
    }

    # Add datetime to the log
    $LogToWrite = (Get-Date).ToString() + ": " + $LogToWrite
    Add-content $LogFilePath -value $LogToWrite        
}

<#
.SYNOPSIS
Verify the path on local system if it exist and its type.
#>
function Confirm-Path {
    param (
        $Path, $IsDirectory
    )    

    if (Test-Path $Path) {  
        # Convert to full path of the file
        $Path = Resolve-Path $Path          
        if ($IsDirectory) {
            Write-Log -LogToWrite "Verifying if $Path is directory..."
            # Check if source path is a folder
            if (!((Get-Item $Path) -is [System.IO.DirectoryInfo])) {
                Write-Log -LogToWrite "The provided path is not directory. Please correct and try again!"                
                return  $false         
            } 
        }
        else {
            Write-Log -LogToWrite "Verifying if $Path is file..."
            # Check if source path is point to a file
            if (!((Get-Item $Path) -is [System.IO.FileInfo])) {
                Write-Log -LogToWrite "The provided path is not a file. Please correct and try again!"                
                return  $false        
            } 
        }
    }
    else {
        Write-Log -LogToWrite "The specified path $Path does not exist. Please double check and try again!"        
        return $false
    }

    Write-Log -LogToWrite "The path looks good!`n"
    return $true    
}