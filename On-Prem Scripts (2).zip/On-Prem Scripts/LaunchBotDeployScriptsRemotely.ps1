<#
.SYNOPSIS
Launch BotDeploy script on systems remotely.

.DESCRIPTION
This script will help launch BotDeploy script on mac systems remotely.
Documentation: https://devdiv.visualstudio.com/Engineering/_wiki/wikis/CNEKB/24096/Process-Using-BotDeploy-to-image-Xamarin-MAC-machines

- Dependencies
    - Posh-SSH module
        Script will check and install if the module is not installed.
    - Access to Azure KeyVault for user password and BotDeploy Key
        If not provided as parameters, the script will try to let the user signin to Azure and read from Azure KeyVault.
        If failed to read from KeyVault, it will prompt for user to manually input the key and password.

.PARAMETER PathForHostsFile
Use this to specify the .ini file that contains the hosts information. There could be multiple sections in one file.
Use together with MultiHosts
Example:
    [VSM_XAM]
    VSM-XAM-10	ansible_host=10.218.200.24
    VSM-XAM-11	ansible_host=10.218.200.26
    
    [XAMMAC]
    BOT-0050	ansible_host=10.195.217.20
    BOT-0065	ansible_host=10.195.217.144    
    
.PARAMETER MultiHosts
Use this to indicate running commands on multiple systems.
Use together with PathForHostsFile

.PARAMETER HostIP
Use this to specify the system IP which you would like to run commands on.

.PARAMETER HostName
Use this to specify the name of system which you would like to run commands on.

.PARAMETER User
Use this to specify the user you would like to use to deploy the workflow in BotDeploy

.PARAMETER Pass
Optional. Use this to specify the password of the user. 
If not provided, the script will try to read from Azure KeyVault. 
If failed to read from Azure, it will prompt to let user input the password.

.PARAMETER BotDeployKey
Optional. Use this to specify the Key to use for BotDeploy. 
If not provided, the script will try to read from Azure KeyVault "uip-mac"
If failed to read from Azure, it will prompt to let user input the key.

.PARAMETER TeamName
Use this to specify the team name. 
Currently support: xamarin

.PARAMETER WorkflowID
Use this to specify the workflow ID to use.
All available workflows could be viewed at https://botdeploy-web.azurewebsites.net/ 

.PARAMETER BDScriptPath
Optional. Use this to specify the BotDeploy script path. 
Default is "/Volumes/BotDeploy/mac_image"

.EXAMPLE

# Run against multiple hosts
.\LaunchBotDeployScriptsRemotely.ps1 -PathForHostsFile .\SharedPool.ini -MultiHosts -User builder -TeamName xamarin -WorkflowID 58 -BDScriptPath /Volumes/BotDeploy/mac_image

.EXAMPLE
# Run against single host
.\LaunchBotDeployScriptsRemotely.ps1 -HostIP 10.218.201.27 -HostName VSM-XAM-22 -User builder -TeamName xamarin -WorkflowID 58 -BDScriptPath /Volumes/BotDeploy/mac_image

#>

param(       
    # Hosts to run commands      
    [Parameter(Mandatory = $false)]
    [string]
    $PathForHostsFile,
    # Indicate whether to process multi hosts 
    [Parameter(Mandatory = $false)]
    [switch]
    $MultiHosts,
    # Host to run commands 
    [Parameter(Mandatory = $false)]  
    [string]
    $HostIP,
    # Host to run commands  
    [Parameter(Mandatory = $false)]  
    [string]
    $HostName,
    [Parameter(Mandatory = $false)]
    [string]
    $User,
    [Parameter(Mandatory = $false)]   
    [string]
    $Pass,
    [Parameter(Mandatory = $false)]   
    [string]
    $BotDeployKey,
    [Parameter(Mandatory = $false)]    
    [string]
    $TeamName,
    [Parameter(Mandatory = $false)]
    [int32]
    $WorkflowID,
    [Parameter(Mandatory = $false)]
    [string]
    $BDScriptPath
)

$ErrorActionPreference = "Stop"
$failToImportModule = "Failed to import module files. Please make sure you have the Modules folder with following module files in same directory with this script and try again.`n ConsoleModule.psm1 `n FileModule.psm1 `n ProcessAnsibleInventoryFileModule.psm1 `n AzureModule.psm1"

try {
    Import-Module -Name $PSScriptRoot'\Modules\ConsoleModule.psm1' -Force   
    Import-Module -Name $PSScriptRoot'\Modules\FileModule.psm1' -Force
    Import-Module -Name $PSScriptRoot'\Modules\ProcessAnsibleInventoryFileModule.psm1' -Force
    Import-Module -Name $PSScriptRoot'\Modules\AzureModule.psm1' -Force
}
catch {
    Write-Host $failToImportModule -ForegroundColor Red
    return
}



<#
.SYNOPSIS 
Check and make sure all dependencies are installed
#>
function Import-RequiredModules {
    Write-Log -LogToWrite "Checking if required modules are installed..."
    try {
       
        #####################################################
        # Posh-SSH
        #####################################################
        Write-Log -LogToWrite "Checking Posh-SSH..."

        $poshSSHModule = "Posh-SSH"
        $installed = Get-Module -ListAvailable -Name $poshSSHModule   
    
        if ($null -eq $installed) {
            # If not installed, install Posh-SSH        
            # Write-Host "Posh-SSH module does not exist. Installing..." -ForegroundColor Magenta
            Write-Log -LogToWrite "Posh-SSH module does not exist. Installing..."
            try {
                Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
                Install-Module Posh-SSH -Force
                Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force
                # Write-Host "Posh-SSH successfully installed." -ForegroundColor Green
                Write-Log -LogToWrite "Posh-SSH successfully installed."
            }
            catch {
                Write-Log -LogToWrite "Failed to install moduel Posh-SSH with error: $($_.Exception)"
                Write-Error "Failed to install moduel Posh-SSH with error: $($_.Exception)"
            }
           
        }
    
        Write-Log -LogToWrite "All required modules have been installed!`n"
    }
    catch {
        Write-Error "Failed to check required modules/softwares with error: $_"
    }
}


<#
.SYNOPSIS
Run command for launching BotDeploy scripts
Doc: https://devdiv.visualstudio.com/Engineering/_wiki/wikis/CNEKB/24096/Process-Using-BotDeploy-to-image-Xamarin-MAC-machines 
#>
function Invoke-BotDeployCommand {
    param(
        [Parameter(Mandatory = $true)]
        [string]
        $HostName,
        [Parameter(Mandatory = $true)]
        [string]
        $HostIP,
        [Parameter(Mandatory = $true)]
        [string]
        $BotDeployCommand,
        [Parameter(Mandatory = $true)]
        [pscredential]
        $Credential
    )

    try {
        if ($BotDeployCommand) {
            $session = New-SSHSession -ComputerName $HostIP -Credential $Credential -Force

            try {
                Write-Host "Launching BotDeploy script and waiting for 10 seconds" -ForegroundColor Cyan
                $result = Invoke-SSHCommand -SSHSession $session -Command $BotDeployCommand -TimeOut 10        
            }
            catch {
                #   Since Invoke-SSHCommand is waiting for the output from the command, it will throw timeout exception. However it continues on the machine.
                # Exception calling "EndExecute" with "1" argument(s): "Command '/Volumes/BotDeploy/mac_image -m ' has timed out."              
                #   Tried with run the command in background with adding '&' at the end of the command and redirecting all outputs, it could return immediately with succeeded result, 
                # but it failed to complete the process after machine is sent to reimage.
                #   As a workaround, catching the timeout exception here and wait around 1 minute to verify files are downloading to BotDeploy volume to make sure the process is running as expected
                if ($_.Exception.Message -like "*has timed out*") {
                    Write-Log -LogToWrite "Verifying..."
                    Write-Host "Verifying..." -ForegroundColor Cyan
                    # Get current file count under BotDeploy volumn
                    $command = "cd /Volumes/BotDeploy; ls | wc -l"
                    $fileCount = Invoke-SSHCommand -SSHSession $session -Command $command
                    Write-Log "Currently there are $($fileCount.Output) files under BotDeploy volume on host $HostName : $HostIP. Waiting 1 minute and check again."
                    Write-Host "Currently there are $($fileCount.Output) files under BotDeploy volume on host $HostName : $HostIP. Waiting 1 minute and check again."
                    # Wait 1 minute then verify if files are downloading to BotDeploy volumn
                    Start-Sleep -Seconds 60
                    $fileCountAfter1 = Invoke-SSHCommand -SSHSession $session -Command $command
                    Write-Log "Now there are       $($fileCountAfter1.Output) files under BotDeploy volume after 1 minute on host $HostName : $HostIP."
                    Write-Host "Now there are       $($fileCountAfter1.Output) files under BotDeploy volume after 1 minute on host $HostName : $HostIP."
                    if (($($fileCountAfter1.Output) -gt 5) -or ($($fileCountAfter1.Output) -gt $($fileCount.Output))) {
                        Write-Log -LogToWrite "Successfully launched BotDeploy script on $HostName : $HostIP."
                        Write-Host "Successfully launched BotDeploy script on $HostName : $HostIP." -ForegroundColor Green
                        return $true
                    }
                    else {
                        # If could not determin if there is new files downloaded, list the files with creation time in BotDeploy Volume to let user verify
                        $command = "cd /Volumes/BotDeploy; ls -l"
                        $files = Invoke-SSHCommand -SSHSession $session -Command $command
                        Write-Log -LogToWrite "Looks like there is no new files are downloading to BotDeploy Volume. Please verify. "                        
                        Write-Host "Looks like there is no new file downloaded to BotDeploy volume. Please verify." -ForegroundColor Cyan
                        $files.Output | Format-Table | Out-String | % { Write-Host $_ ; Write-Log -LogToWrite $_ }
                        $title = 'Confirm file list'
                        $question = 'Are files above looking correct for the BotDeploy deployment?'        
                        $decision = Show-ConfirmMsg -Title $title -Content $question 
                        if ($decision -eq 0) {
                            return $true
                        }
                        else {
                            return $false
                        }                        
                    }
                }
                else {
                    Write-Log -LogToWrite "Failed to launch BotDeploy script with error $_"
                    Write-Host "Failed to launch BotDeploy script with error $_" -ForegroundColor Red
                    return $false
                }
            }            
        }
        else {
            throw "Command is not available."
        }
    }
    catch {
        Write-Error "Failed to launch BotDeploy script with command $BotDeployCommand with error $_" -ErrorAction Continue
    }
    finally {
        if ($session) {
            Remove-SSHSession -SSHSession $session | Out-Null
        }
    }
}

<#
 .SYNOPSIS  
 Check if BotDeploy script file is on the host  
 .PARAMETER HostIP
 Host to verify if the script file exists
 .PARAMETER Credential                   
 Credential will be used to connect to the host
 .PARAMETER BDScriptPath
 The path for BotDeploy script. Default is "/Volumes/BotDeploy/mac_image"
#>
function Confirm-BotDeployScript {
    param(
        [parameter(Mandatory = $true)]
        [string]
        $HostIP,
        [parameter(Mandatory = $true)]
        [pscredential]
        $Credential,
        [parameter(Mandatory = $false)]
        [string]
        $BDScriptPath
    )
    try {
        # Set default path if not provided
        if (!$BDScriptPath) {
            $BDScriptPath = "/Volumes/BotDeploy/mac_image"
        }
        $Command = "if [ -f $BDScriptPath ]; then echo 'true'; else echo 'false'; fi"

        $session = New-SSHSession -ComputerName $HostIP -Credential $Credential -Force
        $result = Invoke-SSHCommand -SSHSession $session -Command $Command

        if ($result.Output -eq 'true') {
            return $true
        }
        else {
            return $false
        }
    }
    catch {
        Write-Host "Failed to verify BotDeploy script for host $HostIP with error: $($_.Exception.Message)" -ForegroundColor Red
    }
    finally {
        if ($session) {
            Remove-SSHSession $session | Out-Null
        }    
    }
}

<#
.SYNOPSIS
Get password for the user
#>
function Get-UserCredential {
    param(
        [Parameter(Mandatory = $true)]
        [string]
        $UserName
    )

    # Get the user password from Azure KeyVault or user's input if failed to read from KeyVault
    switch ($UserName) {
        # Use the KV from our internal resouces        
        "builder" { 
            # https://ms.portal.azure.com/#@microsoft.onmicrosoft.com/resource/subscriptions/bd62906c-0a81-43c3-a2f8-126e4cf66ada/resourceGroups/DevDivKeyVault/providers/Microsoft.KeyVault/vaults/DDFunESSupport-Xamarin/overview
            $kvName = "DDFunESSupport-Xamarin"
            $secretName = "Xamarin-Builder-Secret"
            break 
        }
        "ddfun" {
            #https://ms.portal.azure.com/#@microsoft.onmicrosoft.com/resource/subscriptions/bd62906c-0a81-43c3-a2f8-126e4cf66ada/resourceGroups/DevDivKeyVault/providers/Microsoft.KeyVault/vaults/DDFunESSupport/overview
            $kvName = "DDFunESSupport"
            $secretName = "MAC-DDFUN-Password"                
            break
        }
        default {                
            break
        }
    }

    if ($kvName -and $secretName) {
        try {    
            Write-Host "Trying to get password for user $UserName from Azure KV $kvName with secret $secretName" -ForegroundColor Cyan                           
            $pass = Get-AzureSecret -KeyVault $kvName -Secret $secretName
            if (!$pass) {
                $pass = Read-Host "Failed to get password for user $UserName from Azure. Please enter manually" -AsSecureString
                
            }                
        }
        catch {
            $pass = Read-Host "Failed to get password for user $UserName from Azure. Please enter manually" -AsSecureString
        }
    }
    else {
        $pass = Read-Host "No KeyVault set for $UserName to read from Azure. Please enter manually" -AsSecureString
    } 
    
    return $pass
}

<#
.SYNOPSIS
Build the command line to run on host(s)
#>
function Get-BotDeployCommandToRun {
    param(
        [Parameter(Mandatory = $true)]       
        [string]
        $UserName,
        [parameter(Mandatory = $true)]
        [Int32]
        $WorkflowID,
        [parameter(Mandatory = $true)]
        [string]
        $TeamName,
        [Parameter(Mandatory = $false)]
        [string]
        $BotDeployScriptPath
    )

    try {

        if (!$BotDeployScriptPath) {
            # Use default path
            $BotDeployScriptPath = "/Volumes/BotDeploy/mac_image"
        }
        $command += $BotDeployScriptPath + " "
    
        if (!$BotDeployKey) {
            # Signin to Azure with current user to retrieve the Keys and password from KeyVault
            $azContext = Connect-AzAccount -DeviceCode

            # Get the Key from https://ms.portal.azure.com/#@microsoft.onmicrosoft.com/asset/Microsoft_Azure_KeyVault/Secret/https://uip-mac.vault.azure.net/secrets/BotDeployKey-Prod
            # If failed, prompt to user to enter manually
            try {
                $key = Get-AzureSecret -KeyVault uip-mac -Secret BotDeployKey-Prod
                if (!$key) {
                    $key = Read-Host "Failed to get BotDeploy Key from Azure. Please enter manually"
                }
            }
            catch {
                $key = Read-Host "Failed to get BotDeploy key from Azure. Please enter manually"
            }
        }
        else {
            $key = $BotDeployKey
        }
    
        $command += "-m $key "   
        
        # Get user password              
        if (!$Global:pass) {            
            $Global:pass = Get-UserCredential -UserName $UserName              
        }
        $command += "-p $($Global:pass) -u $UserName "
    
        $command += "-w $WorkflowID -t $TeamName"
    
        return $command
    }
    catch {
        Write-Error "Failed to build command for launching BotDeploy script with error: $_" 
    }
    finally {
        # Signout Azure
        if ($azContext) {
            Disconnect-AzAccount | Out-Null
        }
    }    
}


Write-Log -LogToWrite "`n----------------------------Start Process for launching BotDeploy remotely----------------------------"  
Write-Log -LogToWrite "-------------------------Pre-Checking-------------------------"
Write-Host "-----------------Pre-checking-----------------" -ForegroundColor Cyan
Import-RequiredModules
# Signin to Azure to retrieve BotDeploy key and user credential
Write-Host "Signin to Azure to retrieve BotDeploy key and user credential" -ForegroundColor Cyan
Connect-AzAccount -DeviceCode | Out-Null
Write-Host "Pre-checking Done!" -ForegroundColor Green
#####################################################
# Check parameters to make sure they are set properly
#####################################################
## Host(s) information
$Global:cred = $null
if (!($MultiHosts -and $PathForHostsFile) -and !($HostIP -and $HostName)) {
    $title = 'Would you like to process multiple hosts?'
    $question = 'Yes for Multiple hosts, No for single host. Ctrl + C to cancel the process.'        
    $decision = Show-ConfirmMsg -Title $title -Content $question  
    if ($decision -eq 0) {
        $MultiHosts = $true            
        Write-Host "User would like to work on multiple hosts!" -ForegroundColor Green
        do {
            Write-Host "Please specify the path for a .ini file contains the hosts to process. Example: `n[VSM_XAM] `nVSM-XAM-10     ansible_host=10.218.200.24 `nVSM-XAM-11     ansible_host=10.218.200.26 `n" -ForegroundColor Cyan
            $PathForHostsFile = Read-Host "Enter the path for the .ini file contains hosts" 
        }while (!(Resolve-Path $PathForHostsFile -ErrorAction SilentlyContinue))
        
        # Retrieve credential for connecting the host
        Write-Log -LogToWrite "Get credential to connect to the host"
        Write-Host "Get credential to connect to the host" -ForegroundColor Cyan        
        $User = Read-Host "Enter the user name use for BotDeploy. Options: builder, ddfun"  
        if (!$Global:pass) {        
            $Global:pass = Get-UserCredential -UserName $User                 
        }            

        $Global:cred = [PSCredential]::New($User, (ConvertTo-SecureString $Global:pass -AsPlainText -Force))
    }
    else {
        do {
            do {                   
                $HostName = Read-Host "Enter the name for the host"
            }while (!$HostName.Trim())
            $HostName = $HostName.Trim()            
        
            do {                   
                $HostIP = Read-Host "Enter the IP address for the host"
            }while (!$HostIP.Trim())
            $HostIP = $HostIP.Trim()            
            
            # Retrieve credential for connecting the host
            Write-Log -LogToWrite "Get credential to connect to the host"
            Write-Host "Get credential to connect to the host" -ForegroundColor Cyan
            
            $User = Read-Host "Enter the user name use for BotDeploy. Options: builder, ddfun"
                    
            if (!$Global:pass) {        
                $Global:pass = Get-UserCredential -UserName $User                         
            }              
            
            $Global:cred = [PSCredential]::New($User, (ConvertTo-SecureString $Global:pass -AsPlainText -Force))
                       
        }while (!(Test-HostIP -HostName $HostName -HostIP $HostIP -Credential $Global:cred)) 
    }
}

## BotDeploy key
if (!$BotDeployKey) {
    Write-Host "Enter the Key used for BotDeploy, or press Enter directly to sign in to Azure and read from Azure KeyVault with your credential" -ForegroundColor Cyan
    $BotDeployKey = Read-Host "Enter the Key used for BotDeploy"
    if (!$BotDeployKey) {
        # Get the Key from https://ms.portal.azure.com/#@microsoft.onmicrosoft.com/asset/Microsoft_Azure_KeyVault/Secret/https://uip-mac.vault.azure.net/secrets/BotDeployKey-Prod
        # If failed, prompt to user to enter manually
        $kvName = "uip-mac"
        $secrectName = "BotDeployKey-Prod"
        try {
            $BotDeployKey = Get-AzureSecret -KeyVault $kvName -Secret $secrectName
            if (!$BotDeployKey) {
                $BotDeployKey = Read-Host "Failed to get BotDeploy Key from Azure. Please enter manually"
            }
        }
        catch {
            $BotDeployKey = Read-Host "Failed to get BotDeploy key from Azure. Please enter manually"
        }
    }    
}

## Team
if (!$TeamName) {
    $TeamName = Read-Host "Enter the name of the Team"
}

## Workflow
if (!$WorkflowID) {
    $WorkflowID = Read-Host "Enter the workflow ID"
}

## Set default BotDeploy Script path on systems
if (!$BDScriptPath) {
    $BDScriptPath = Read-Host "Enter the BotDeploy script path on host, or press Enter to use default path '/Volumes/BotDeploy/mac_image'"  
    if (!$BDScriptPath) {
        $BDScriptPath = "/Volumes/BotDeploy/mac_image"
    }  
}

#######################################################
## Start process
#######################################################
try {  
    Write-Log -LogToWrite "-------------------------Building the commands to run ----------------------------"
    Write-Host "-----------------Building the commands to run-----------------" -ForegroundColor Cyan
    $bdCommand = Get-BotDeployCommandToRun -UserName $User -WorkflowID $WorkflowID -TeamName $TeamName -BotDeployScriptPath $BDScriptPath
    $title = 'Does the command look good to run on host(s)?'
    $question = $bdCommand         
    $decision = Show-ConfirmMsg -Title $title -Content $question 
    
    # Process if user confirm the command to run
    if ($decision -eq 0) {           
        
        $hostsWithoutBTScript = [System.Collections.ArrayList]@()
        $hostsFailToLaunchBTScript = [System.Collections.ArrayList]@()        
      
        #Get the host(s) to run against 
        if ($MultiHosts) {
            ################################################################################
            # Process with multiple hosts
            ################################################################################  
            Write-Host "Read hosts from the provided ini file $PathForHostsFile..." -ForegroundColor Cyan
            $hosts = Get-HostsToProcess -PathForHostsFile $PathForHostsFile
            Write-Host "Done!" -ForegroundColor Green

            # Print out the hosts list for user to confirm
            Write-Log -LogToWrite "Hosts retrieved from inventory file:"
            foreach ($key in $hosts.Keys) {            
                Write-Log -LogToWrite "Found $($($($hosts.Item($key)).Keys).Count) hosts for $key"
                Write-Host "Found $($($($hosts.Item($key)).Keys).Count) hosts for $key" -ForegroundColor Green
                $hostsForSection = $hosts.Item($key)
                $hostNames = $hostsForSection.Keys 
                $hostNames | ForEach-Object {
                    $hostIP = $hostsForSection.Item($_)                    
                    Write-Host "    $_ : $hostIP"
                }
            }

            $title = 'Confirm to process hosts'
            $question = 'Would you like to continue to process the hosts?'        
            $decision = Show-ConfirmMsg -Title $title -Content $question  

            # Process if the hosts looks good for user
            if ($decision -eq 0) { 
                Write-Log -LogToWrite "User would like to continue processing these hosts."   

                foreach ($key in $hosts.Keys) {
                    Write-Log -LogToWrite "---------------Processing hosts for $key---------------"
                    Write-Host "`n--------------Procession hosts for $key--------------`n" -ForegroundColor Cyan
                    $hostsForSection = $hosts.Item($key)
                    $hostNames = $hostsForSection.Keys                
                
                    if ($hostNames.Count -gt 0) {
                        $hostNames | ForEach-Object {
                            try {
                                $hostIP = $hostsForSection.Item($_)

                                # Verify if the host name and host IP match
                                $rel = Test-HostIP -HostName $_ -HostIP $HostIP -Credential $Global:cred
                                if ($rel) {

                                    Write-Log "--------------Procession hosts for $_ : $hostIP--------------"
                                    Write-Host "`n--------------Procession hosts for $_ : $hostIP--------------" -ForegroundColor Cyan
                                    # Step1 Check if BotDeploy volumn and BotDeploy script exist on the host
                                    #   If not exist, add the host to list and display to user later.
                                    if (! (Confirm-BotDeployScript -HostIP $hostIP -Credential $Global:cred -BDScriptPath $BDScriptPath)) {
                                        Write-Log -LogToWrite "Host $_ ($hostIP) does not have script at $BDScriptPath."
                                        Write-Host "Host $_ ($hostIP) does not have script at $BDScriptPath." -ForegroundColor Red
                                        $hostsWithoutBTScript.Add("$_ : $hostIP") | Out-Null
                                        continue
                                    }
                                    Write-Host "Done!" -ForegroundColor Green

                                    # Step 2 Run the script file 
                                    Write-Log -LogToWrite "Launching BotDeploy on Host $_ ($hostIP)."
                                    Write-Host "Launching BotDeploy on Host $_ ($hostIP)." -ForegroundColor Cyan
                                    $launchResult = Invoke-BotDeployCommand -HostName $_ -HostIP $hostIP -BotDeployCommand $bdCommand -Credential $Global:cred
                                    if (!$launchResult) {
                                        $hostsFailToLaunchBTScript.Add("$_ : $hostIP") | Out-Null
                                    }
                                    else {
                                        Write-Log -LogToWrite "Done for host $_ !"
                                        Write-Host "Done for host $_ !" -ForegroundColor Green
                                    }
                                }
                                elseif ($rel -eq $false) {
                                    Write-Host "Host name of $hostIP does not match $_. Skipped." -ForegroundColor Red
                                    Write-Log "Host name of $hostIP does not match $_. Skipped."
                                    $hostsFailToLaunchBTScript.Add("$_ : $hostIP") | Out-Null
                                }
                                else {
                                    $hostsFailToLaunchBTScript.Add("$_ : $hostIP") | Out-Null
                                }
                            }
                            catch {
                                Write-Log -LogToWrite "Failed to process host $_ with error: $_"
                                Write-Error "Failed to process host $_." -ErrorAction Continue
                                $hostsFailToLaunchBTScript.Add("$_ : ") | Out-Null
                            }
                        }
                    }
                }           
            }    
        }
        else {
            #################################################################################
            # Process with single host
            #################################################################################
            Write-Log -LogToWrite "-------------------------Processing Host $HostIP-------------------------"                 
            Write-Host "-------------------------Processing Host $HostIP----------------------------" -ForegroundColor Cyan
            # Step1 Check if BotDeploy volumn and BotDeploy script exist on the host
            #   If not exist, add the host to list and display to user.
            Write-Host "Checking if the BotDeploy script exist on host $HostName : $HostIP" -ForegroundColor Cyan
            $bdScriptExist = Confirm-BotDeployScript -HostIP $HostIP -Credential $Global:cred -BDScriptPath $BDScriptPath
            if ($bdScriptExist) {
                Write-Host "Done!" -ForegroundColor Green
                # Step 2 Run the script file 
                $launchResult = Invoke-BotDeployCommand -HostName $HostName -HostIP $HostIP -BotDeployCommand $bdCommand -Credential $Global:cred  
                if (!$launchResult) {
                    $hostsFailToLaunchBTScript.Add("$HostName : $HostIP")
                }                             
            }
            else {
                Write-Log -LogToWrite "Host $HostName ($HostIP) does not have script at $BDScriptPath."
                Write-Host "Host $HostName ($HostIP) does not have script at $BDScriptPath." -ForegroundColor Red
                $hostsWithoutBTScript.Add("$HostName : $HostIP") | Out-Null
            }
        }

        # Output hosts have no BotDeploy script
        if ($hostsWithoutBTScript.Count -gt 0) {
            Write-Log -LogToWrite "-------------------------Hosts need manually process-------------------------"
            Write-Log -LogToWrite "BotDeploy volumn or BotDeploy script not exist on following host(s) at $BDScriptPath. Please review and process manually."
            Write-Host "BotDeploy volumn or BotDeploy script not exist on following host(s) at $BDScriptPath. Please review and process manually." -ForegroundColor Red
            $hostsWithoutBTScript | ForEach-Object {
                # Output the hosts need manually process
                Write-Log -LogToWrite "  $_"
                Write-Host "  $_" -ForegroundColor Red
            }
        }

        # Output hosts failed to launch BotDeploy script
        if ($hostsFailToLaunchBTScript.Count -gt 0) {
            Write-Log -LogToWrite "-------------------------Hosts failed to launch script and need review-------------------------"
            Write-Log -LogToWrite "Failed to launch BotDeploy script on following host(s). Please review errors and try again."
            Write-Host "Failed to launch BotDeploy script on following host(s). Please review errors and try again." -ForegroundColor Red
            $hostsFailToLaunchBTScript | ForEach-Object {
                # Output the hosts need review and manually process
                Write-Log -LogToWrite "  $_"
                Write-Host "  $_" -ForegroundColor Red
            }
        }
    }
    else {
        Write-Host "Please adjust the paremeters and try again. Exit." -ForegroundColor Cyan
    }
}
catch {
    Write-Log -LogToWrite "Script failed with error: $_"
    Write-Error "Script failed with error: $_"
}
finally
{
    if(!(Get-AzureAccount | Out-Null))
    {
        Disconnect-AzAccount | Out-Null
    }
}