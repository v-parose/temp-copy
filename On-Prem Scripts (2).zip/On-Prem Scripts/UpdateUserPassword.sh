#!/usr/bin/env bash

# Get arguments
while getopts u:p:m:t: args
do
    case $args in
        u)  username=$OPTARG;;
        p)  newpassword=$OPTARG;;
        m)  adminuser=$OPTARG;;
        t)  adminpwd=$OPTARG;;
    esac
done

# Check OS Type
function check_OS(){
    unameOutput=$(uname -s)

    case "${unameOutput}" in
    Linux*)   machine=Linux;;
    Darwin*)  machine=Mac;;
    *)        machine="UNKNOWN:${unameOutput}"
    esac

    echo $machine
}

## Verify if user exist and user role
## Need test on linux and other systems
function check_user(){
    userName=$1
    ostype=$2

    if id -u $userName >/dev/null 2>&1; then
        if [[ $ostype == "Mac" ]]; then
            if id -Gn $userName | grep -q -w admin; then
                echo "admin"
            else
                echo "normal"
            fi
        elif [[ $ostype == "Linux" ]]; then
            if id -Gn $userName | grep -q -w sudo; then
                echo "admin"
            else
                echo "normal"
            fi
        fi
    else
        echo "not exist"
    fi
}


# Check if user exist
 type=$(check_OS)
if [[ "$(check_user $username $type)" != "not exist" ]]; then
    if [ "${type}" == "Mac" ]; then
        # Update user password for Mac with sysadminctl                   
        sudo sysadminctl -resetPasswordFor $username -newPassword $newpassword -adminUser $adminuser -adminPassword $adminpwd
        echo "succeeded"
    elif [ "${type}" == "Linux" ]; then
        # Update user password for Linux 
        echo "$username:$newpassword" | sudo chpasswd  
        echo "succeeded"
    fi
else    
        echo "user not exist"
fi