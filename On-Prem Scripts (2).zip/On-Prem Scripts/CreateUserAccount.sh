#!/usr/bin/env bash

# Get arguments
while getopts u:p:a:m:t args
do
    case $args in
        u)  username=$OPTARG;;
        p)  password=$OPTARG;;
        a)  isadmin=$OPTARG;;
        m)  adminuser=$OPTARG;;
        t)  adminpwd=$OPTARG;;
    esac
done

# Check OS Type
function check_OS(){
    unameOutput=$(uname -s)

    case "${unameOutput}" in
    Linux*)   machine=Linux;;
    Darwin*)  machine=Mac;;
    *)        machine="UNKNOWN:${unameOutput}"
    esac

    echo $machine
}

## Verify if user exist and user role
function check_user(){
    userName=$1
    ostype=$2

    if id -u $userName >/dev/null 2>&1; then
        if [[ $ostype == "Mac" ]]; then
            if id -Gn $userName | grep -q -w admin; then
                echo "admin"
            else
                echo "normal"
            fi
        elif [[ $ostype == "Linux" ]]; then
            if id -Gn $userName | grep -q -w sudo; then
                echo "admin"
            else
                echo "normal"
            fi
        fi
    else
        echo "not exist"
    fi
}

## Delete exist user
function delete_user(){
    userName=$1
    ostype=$2
    if [[ $ostype == "Mac" ]]; then
        sudo sysadminctl -deleteUser $userName
    elif [[ $ostype == "Linux" ]]; then
        sudo userdel -r $userName
    fi
}


type=$(check_OS)

## If user alreay exist, delete it
if [[ "$(check_user $username)" != "not exist" ]]; then
    echo "User $username exists. Deleting..."
    delete_user $username $type
fi

if [ "${type}" == "Mac" ]; then
    # Create new user for Mac with sysadminctl
    if [ $isadmin == "true" ]; then
        # Create user as admin
        sudo sysadminctl -addUser $username -fullName $username -password $password -admin -adminUser $adminuser -adminPassword $adminpwd 
        
        # Verify user is created succeeded
        if [[ "$(check_user $username $type)" == "admin" ]]; then
            echo "succeeded"
        else
            echo "failed"
        fi            
    else
        # Create user as normal user
        sudo sysadminctl -addUser $username -fullName $username -password $password -adminUser $adminuser -adminPassword $adminpwd
        
        # Verify user is created succeeded
        if [[ "$(check_user $username $type)" == "normal" ]]; then
            echo "succeeded"
        else
            echo "failed"
        fi
    fi
elif [ "${type}" == "Linux" ]; then
    # Create new user for Linux with UserAdd   
    if [[ $isadmin == "true" ]]; then
        # Create user as admin
        sudo useradd -p $(openssl passwd -6 $password) -m $username
        sudo usermod -aG sudo $username       
        
        # Verify user is created successfully
        if [[ "$(check_user $username $type)" == "admin" ]]; then
            echo "succeeded"
        else
            echo "failed"
        fi
    else
        # Create normal user
        sudo useradd -p $(openssl passwd -6 $password) -m $username  

        # Verify user is created succeeded
        if [[ "$(check_user $username $type)" == "normal" ]]; then
            echo "succeeded"
        else
            echo "failed"
        fi
    fi
fi