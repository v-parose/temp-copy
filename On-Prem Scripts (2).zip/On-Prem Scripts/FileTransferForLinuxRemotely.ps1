<#
.SYNOPSIS
Provide support for copying files from local system to remote Linux or Mac system(s), or copy files from one place to another on remote system(s).

.DESCRIPTION
Use pscp provided by Putty to copy file from Windows to Linux/MacOS
Use Posh-SSH to copy file on Linux/MacOS system from one place to another

Use this script in following scenarios
- Copy single file from local system to remote system
    -Single remote system
        .\CopyFiles.ps1 -SourcePath -TargetDir -HostIP -FromLocalToRemote
    -Multiple remote systems
        .\CopyFiles.ps1 -SourcePath -TargetDir -PathForHostsFile -MultiHosts -FromLocalToRemote
- Copy a directory from local system to remote system
    -Single remote system
        .\CopyFiles.ps1 -SourcePath -TargetDir -HostIP -FromLocalToRemote -CopyDirectory
    -Multiple remote systems
        .\CopyFiles.ps1 -SourcePath -TargetDir -PathForHostsFile -MultiHosts -FromLocalToRemote -CopyDirectory
- Copy single file on remote system from the given path to directory
    -Single remote system
        .\CopyFiles.ps1 -SourcePath -TargetDir -HostIP
    -Multiple remote systems
        .\CopyFiles.ps1 -SourcePath -TargetDir -PathForHostsFile -MultiHosts
- Copy a directory on remote system from the given path to directory
    -Single remote system
        .\CopyFiles.ps1 -SourcePath -TargetDir -HostIP -CopyDirectory
    -Multiple remote systems
        .\CopyFiles.ps1 -SourcePath -TargetDir -PathForHostsFile -MultiHosts -CopyDirectory

.EXAMPLE
- Copy single file from local system to remote system
    -Single remote system
        .\CopyFiles.ps1 -SourcePath .\TestFile -TargetDir Downloads -HostIP 10.10.10.10 -FromLocalToRemote
    -Multiple remote systems
        .\CopyFiles.ps1 -SourcePath .\TestFile -TargetDir Downloads -PathForHostsFile .\TestMac.ini -MultiHosts -FromLocalToRemote

- Copy a directory from local system to remote system
    -Single remote system
        .\CopyFiles.ps1 -SourcePath .\TestFolder -TargetDir Downloads -HostIP 10.10.10.10 -FromLocalToRemote -CopyDirectory
    -Multiple remote systems
        .\CopyFiles.ps1 -SourcePath .\TestFolder -TargetDir Downloads -PathForHostsFile .\TestMac.ini -MultiHosts -FromLocalToRemote -CopyDirectory

- Copy single file on remote system from the given path to directory
    -Single remote system
        .\CopyFiles.ps1 -SourcePath Downloads/TestFile -TargetDir Documents -HostIP 10.10.10.10
    -Multiple remote systems
        .\CopyFiles.ps1 -SourcePath Downloads/TestFile -TargetDir Documents -PathForHostsFile .\TestMac.ini -MultiHosts

- Copy a directory on remote system from the given path to directory
    -Single remote system
        .\CopyFiles.ps1 -SourcePath Downloads/TestFolder -TargetDir Documents -HostIP 10.10.10.10 -CopyDirectory
    -Multiple remote systems
        .\CopyFiles.ps1 -SourcePath Downloads/TestFolder -TargetDir Documents -PathForHostsFile .\TestMac.ini -MultiHosts -CopyDirectory

.NOTES
-DEPENDENCIES
    - PuTTY installed on the server. (Download from https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html)
    - Posh-SSH PowerShell Module

.PARAMETER SourcePath
Path of the file or directory to copy
.PARAMETER TargetDir
Path of the directory the file/directory will be copied to
.PARAMETER PathForHostsFile
Use this together with MultiHosts to specify the .ini file that contains the hosts information. There could be multiple sections in one file.
Example:
    [Section1]
    CPPMAC-ARM64-01		ansible_host=10.250.123.8
    CPPMAC-ARM64-02		ansible_host=10.250.123.6
    [Section2]    
    CPPMAC-ARM64-01		ansible_host=10.250.123.8
    CPPMAC-ARM64-02		ansible_host=10.250.123.6

.PARAMETER MultiHosts
Use this to indicate copying files to multiple systems.
Use together with PathForHostsFile

.PARAMETER HostIP
Use this to pass the system IP when you would like to copy file to one system.

.PARAMETER CopyDirectory
Use this to indicate copying a directory.
If this parameter is used, make sure you are passing a path to directory for parameter SourcePath

.PARAMETER FromLocalToRemote
Use this to indicate copying from local system to remote system(s).
#>
param( 
    # File path      
    [Parameter(mandatory = $false)]
    [string]
    $SourcePath,    
    # Target of the file
    [Parameter(mandatory = $false)]
    [string]
    $TargetDir,
    # Hosts to perform copy operation. Accept ansible inventory file. Format ".ini".    
    [Parameter(mandatory = $false)]
    [string]
    $PathForHostsFile,
    # Indicate whether to process multi hosts    
    [Parameter(Mandatory = $false)]
    [switch]
    $MultiHosts,
    # Host to perform copy operation    
    [Parameter(mandatory = $false)]
    [string]
    $HostIP,    
    # Indicate whether to copy files under directory
    [Parameter(Mandatory = $false)]
    [switch]
    $CopyDirectory,
    # Indicate whether to copy files from local to remote host    
    [Parameter(Mandatory = $false)]
    [switch]
    $FromLocalToRemote
)

$ErrorActionPreference = "Stop"
$failToImportModule = "Failed to import module files. Please make sure you have the Modules folder with following module files in same directory with this script and try again.`n ConsoleModule.psm1 `n FileModule.psm1 `n ProcessAnsibleInventoryFileModule.psm1 `n AzureModule.psm1"

try {
    Import-Module -Name $PSScriptRoot'\Modules\ConsoleModule.psm1' -Force
    Import-Module -Name $PSScriptRoot'\Modules\FileModule.psm1' -Force
    Import-Module -Name $PSScriptRoot'\Modules\ProcessAnsibleInventoryFileModule.psm1' -Force
}
catch {
    Write-Host $failToImportModule -ForegroundColor Red
    return
}

<#
.SYNOPSIS
Check and install or prompt on missing required dependencies
#>
function Import-RequiredModules {
    # Check if Posh-SSH is installed
    Write-Log -LogToWrite "Checking if Posh-SSH module is installed..."
    $poshSSHModule = "Posh-SSH"
    $installed = Get-Module -ListAvailable -Name $poshSSHModule   

    if ($null -eq $installed) {
        # If not installed, install Posh-SSH        
        # Write-Host "Posh-SSH module does not exist. Installing..." -ForegroundColor Magenta
        Write-Log -LogToWrite "Posh-SSH module does not exist. Installing..."
        try {
            Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
            Install-Module Posh-SSH -Force
            Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force
            # Write-Host "Posh-SSH successfully installed." -ForegroundColor Green
            Write-Log -LogToWrite "Posh-SSH successfully installed."
        }
        catch {
            Write-Log -LogToWrite "Failed to install moduel Posh-SSH with error: $($_.Exception)"
            Write-Error "Failed to install moduel Posh-SSH with error: $($_.Exception)"
        }
       
    }   
    
    # Check if puTTY is installed
    try {
        Write-Log -LogToWrite "Checking if PuTTY is installed on system..."
        pscp | Out-Null
    }
    catch {
        Write-Log -LogToWrite "PuTTY is not installed on the system. Exit."
        Write-Error "PuTTY is not installed on the system. Please download and install from https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html. Then restart PowerShell."        
    }

    Write-Log -LogToWrite "All required modules have been installed!`n"
}


<#
.SYNOPSIS
Modify file permission
#>
function Update-FilePermission {
    param(
        $HostIP,
        $Path
    )

    try {
        $session = New-SSHSession -ComputerName $HostIP -Credential $Global:cred -Force

        if ($session) {
            $command = "chmod 755 $Path"
            $result = Invoke-SSHCommand -SSHSession $session -Command $command

            if ($result.ExitStatus -eq 0) {
                Write-Host "Permission for $Path has been updated." -ForegroundColor Green
                Write-Log -LogToWrite "Updated permission for $Path to 755."
            }
            else {
                Write-Host "Failed to update permission for $Path with error $($result.Error)" -ForegroundColor Red
                Write-Log -LogToWrite "Failed to update permission for $Path with error $($result.Error)"
            }
        }
    }
    catch {
        Write-Host "Failed to update permission for $Path with error $($_.Exception)" -ForegroundColor Red
        Write-Log -LogToWrite "Failed to update permission for $Path with error $($_.Exception)"
    }
    finally {
        if ($session) {
            Remove-SSHSession $session | Out-Null
        }
    }

}

<#
Invoke copy command to copy files
Use pscp provided by Putty to copy file from Windows to Linux/MacOS
Use Posh-SSH to copy file on Linux/MacOS system from one place to another
#>
function Invoke-CopyCommand {
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $HostName,
        [Parameter(Mandatory = $true)]
        [string]
        $HostIP,
        [Parameter(Mandatory = $true)]
        [string]
        $SourcePath,
        [Parameter(Mandatory = $true)]
        [string]
        $TargetPath

    )
    # Connect to server 
    $hostToConnect = "$($($Global:cred).Username)@$HostIP"
    $targetPathOnHost = $hostToConnect + ":" + $TargetPath
    $FileName = Split-Path $SourcePath -Leaf
    
    if ($FromLocalToRemote) {
        # Save the password to a file before exectuting PSCP command
        $passFile = "$($env:temp)\pass_$HostName.txt"                        
        [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR(($($Global:cred)).Password)) `
        | Out-File -encoding ascii -FilePath $passFile -NoNewline        

        # Copy file from local system to remote host 
        # Check the existence of the file(dir) to copy when perform copy operation for each host.
        if (Test-Path $SourcePath) {           
            try {                    
                if ($CopyDirectory) {  
                    Write-Log -LogToWrite "    Trying to copy directory $SourcePath from local to host $HostIP...."  
                    Write-Host "Trying to copy directory $SourcePath from local to host $HostIP...." -ForegroundColor Magenta               
                    echo y | pscp -pwfile $passFile -r $SourcePath $targetPathOnHost                                     
                }
                else {
                    Write-Log -LogToWrite "    Trying to copy file $SourcePath from local to host $HostIP...."
                    Write-Host "Trying to copy file $SourcePath from local to host $HostIP...." -ForegroundColor Magenta
                                                
                    echo y | pscp -pwfile $passFile $SourcePath $targetPathOnHost                        
                } 
                
                # Check if copy succeeded
                if ($LASTEXITCODE -eq 0) {
                    Write-Log -LogToWrite "    Successfuly copied file from local to host $HostIP."
                    Write-Host "Successfuly copied file from local to host $HostIP"  -ForegroundColor Green    
                    
                    Update-FilePermission -HostIP $HostIP -Path "$TargetPath/$FileName"
                }
                else {
                    # Throw exception on error.
                    Throw "Failed to copy file from local to host $HostIP" 
                }
            }        
            catch {
                # Log the error and continue to next step
                Write-Log -LogToWrite "    Failed to copy file from local to host $HostIP"
                Write-Error "Failed to copy file with error: $($_.Exception)" -ErrorAction Continue
            }
            finally {
                # Remove the password file
                if (Test-Path -Path $passFile) {
                    Remove-Item $passFile
                }
            }
        }
        else {
            Write-Log "    Could not find $SourcePath on local system. Exit."
            Write-Error "Could not find $SourcePath on local system. Please double check."
        }
    }    
    else {
        # Copy file on the host from source path to target path
    
        try {
            # Since Remote to Remote is not supported in pscp, use SSHSession instead
            $session = New-SSHSession -ComputerName $HostIP -Credential $($Global:cred) -Force
            if ($CopyDirectory) {
                Write-Log -LogToWrite "    Trying to copy directory $SourcePath to $TargetPath on host $HostIP...."
                Write-Host "Trying to copy directory $SourcePath to $TargetPath on host $HostIP...."
                
                $command = "if [ -d $SourcePath ]; then cp -a -v $SourcePath $TargetPath ; else echo 'Dir $SourcePath does not exist' ; fi"           
            }
            else {
                Write-Log -LogToWrite "    Trying to copy file $SourcePath to $TargetPath on host $HostIP...."
                Write-Host "Trying to copy file $SourcePath to $TargetPath on host $HostIP...."
                
                $command = "if [ -f $SourcePath ]; then cp -v $SourcePath $TargetPath ; else echo 'Dir $SourcePath does not exist' ; fi"                
            }
            
            $result = Invoke-SSHCommand -SSHSession $session -Command $command
            
            # Check the copy result
            if ($result.ExitStatus -eq 0) {    
                Write-Log -LogToWrite "    Successfuly copied file(dir) from $SourcePath to $TargetPath on host $HostIP"
                Write-Host "Successfuly copied file on host $HostIP" -ForegroundColor Green    
                
                Update-FilePermission -HostIP $HostIP -Path "$TargetPath/$FileName"
            }
            else {
                Write-Log -LogToWrite "    Faild to copy file(dir) from $SourchPath to $TargetPath on host $HostIP with error $($result.Error)"
                Write-Host "Faild to copy file on host $HostIP with error $($result.Error)" -ForegroundColor Red                
            }
        }
        catch {
            # Log the error for current copy and continue to next step
            Write-Log -LogToWrite "    Failed to copy file on host $HostIP with error: $($_.Exception)"
            Write-Error "Failed to copy file on host $HostIP with error: $($_.Exception)" -ErrorAction Continue
        }  
        finally {
            # Remove SSH session to the host
            if ($null -ne $session) {
                Remove-SSHSession -SSHSession $session | Out-Null
            }            
        }      
    }
}


Write-Log -LogToWrite "`n---------------Start the process for copying files ---------------`n"
Write-Log -LogToWrite "-------------------------Pre-Checking-------------------------"
Import-RequiredModules
######################################################
# Check parameters to make sure they are set properly
######################################################
## Host(s) information
if (!($MultiHosts -and $PathForHostsFile) -and !($HostIP)) {
    $title = 'Would you like to copy files to multiple hosts?'
    $question = 'Yes for Multiple hosts, No for single host. Ctrl + C to cancel the process.'        
    $decision = Show-ConfirmMsg -Title $title -Content $question  
    if ($decision -eq 0) {
        $MultiHosts = $true            
        Write-Host "User would like to copy files to multiple hosts!" -ForegroundColor Green
        do {
            Write-Host "Please specify the path for a .ini file contains the hosts to process. Example: `n[VSM_XAM] `nVSM-XAM-10     ansible_host=10.218.200.24 `nVSM-XAM-11     ansible_host=10.218.200.26 `n" -ForegroundColor Cyan
            $PathForHostsFile = Read-Host "Enter the path for the .ini file contains hosts" 
        }while (!(Resolve-Path $PathForHostsFile -ErrorAction SilentlyContinue))  
        
        # Get the credential to access the hosts from user's input
        Write-Host "`nProvide credential for connecting to the hostS" -ForegroundColor Cyan            
        $Global:cred = Get-CredentialFromInput -UserNameMsg "Enter the username for connecting hosts" -PasswordMsg "Enter the password for connecting hosts"
    }
    else {
        $MultiHosts = $false
        Write-Host "User would like to copy files to single host!" -ForegroundColor Green
        do {
            do {                   
                $HostName = Read-Host "Enter the name for the host"
            }while (!$HostName.Trim())
            $HostName = $HostName.Trim()            
        
            do {                   
                $HostIP = Read-Host "Enter the IP address for the host"
            }while (!$HostIP.Trim())
            $HostIP = $HostIP.Trim()

            # Get the credential to access the host from user's input
            Write-Host "`nProvide credential for connecting to the host" -ForegroundColor Cyan            
            $Global:cred = Get-CredentialFromInput -UserNameMsg "Enter the username for connecting $hostName" -PasswordMsg "Enter the password for connecting $hostName"
        }while (!(Test-HostIP -HostName $HostName -HostIP $HostIP -Credential $Global:cred))
    }
}

## Copy single file or files under a directory
if (!($CopyDirectory.IsPresent)) {
    $title = 'Would you like to copy single file or files under directory?'
    $question = 'Yes for copying single file, No for copying files under a directory. Ctrl + C to cancel the process.'        
    $decision = Show-ConfirmMsg -Title $title -Content $question

    if ($decision -eq 0) {
        $CopyDirectory = $false
        Write-Host "User would like to copy a single file!" -ForegroundColor Green
    }
    else {
        $CopyDirectory = $true
        Write-Host "User would like to copy files under a directory!" -ForegroundColor Green
    }
}

## Copy from local to remote or from location A to B on remote system
if (!($FromLocalToRemote.IsPresent)) {
    $title = 'Would you like to copy files from local to remote systems?'
    $question = 'Yes for copying file from local to remote, No for copying file from location A to location B on the remote system. Ctrl + C to cancel the process.'        
    $decision = Show-ConfirmMsg -Title $title -Content $question

    if ($decision -eq 0) {
        $FromLocalToRemote = $true
        if ($CopyDirectory) {
            do {                
                $SourcePath = Read-Host "Enter the path for the local directory" 
            }while (!(Resolve-Path $SourcePath -ErrorAction SilentlyContinue))   
        }
        else {
            do {                
                $SourcePath = Read-Host "Enter the path for the local file" 
            }while (!(Resolve-Path $SourcePath -ErrorAction SilentlyContinue))   
        }
    }
    else {
        $FromLocalToRemote = $false
        if ($CopyDirectory) {
            $SourcePath = Read-Host "Enter the path for the directory on remote host"
        }
        else {
            $SourcePath = Read-Host "Enter the path for the file on remote host"
        }
    }

    Write-Host "File(s) will be copied from $SourcePath" -ForegroundColor Green 
}

# Verify the source path if is copying from local system to remote system
if ($FromLocalToRemote) {   
    while (!(Confirm-Path -Path $SourcePath -IsDirectory $CopyDirectory)) {
        Write-Host "Path $SourcePath is invalid."
        $SourcePath = Read-Host "Enter the path again" 
    }  
}

# Set target path
if (!$TargetDir) {
    $TargetDir = Read-Host "Enter the path for the directory to copy the file(s) to. E.g., /Volumes/BotDeploy"
    Write-Host "File(s) will be copied to $TargetDir on remote host!" -ForegroundColor Green 
}

$title = 'Looks good to proceed?'
$question = 'Yes to proceed, No to end the script.'        
$decision = Show-ConfirmMsg -Title $title -Content $question
if ($decision -eq 0) {
    ########################################
    # Start the process
    ########################################

    try {   
        
        if ($MultiHosts) {
            ####################################
            # Process with multiple hosts
            ####################################    
            Write-Log -LogToWrite "-------------------------Processing Hosts-------------------------"
            $hosts = Get-HostsToProcess -PathForHostsFile $PathForHostsFile      

            # Print out the hosts list for user to confirm
            Write-Log -LogToWrite "Hosts retrieved from inventory file:"
            foreach ($key in $hosts.Keys) {            
                Write-Log -LogToWrite "    Found $($($($hosts.Item($key)).Keys).Count) hosts for $key"
                Write-Host "Found $($($($hosts.Item($key)).Keys).Count) hosts for $key" -ForegroundColor Green
            }

            $title = 'Confirm to process hosts'
            $question = 'Would you like to continue to process the hosts?'        
            $decision = Show-ConfirmMsg -Title $title -Content $question        
            if ($decision -eq 0) { 
                Write-Log -LogToWrite "User would like to continue processing these hosts."                          
                foreach ($key in $hosts.Keys) {
                    Write-Log -LogToWrite "  ---------------Processing hosts for $key---------------"
                    Write-Host "`n--------------Procession hosts for $key--------------`n" -ForegroundColor Cyan
                    $hostsForSection = $hosts.Item($key)

                    $hosts = $hostsForSection.Keys
                    $hosts | ForEach-Object {
                        $hostIP = $hostsForSection.Item($_)  
                        $rel = Test-HostIP -HostName $_ -HostIP $hostIP -Credential $Global:cred
                        if ($rel) {                        
                            Write-Log -LogToWrite "    ----------Processing host $_ : $hostIP----------"                   
                            Write-Host "`n---Processing host $_ : $hostIP---" -ForegroundColor Cyan
                            Invoke-CopyCommand -HostName $_ -HostIP $hostIP -SourcePath $SourcePath -TargetPath $TargetDir
                        }
                        elseif($rel -eq $false) {
                            Write-Host "Host name of $hostIP does not match $_. Skipped." -ForegroundColor Red
                            Write-Log "Host name of $hostIP does not match $_. Skipped."
                        }
                    }
                }           
            }
        }
        else {
            ####################################
            # Process with single hosts
            ####################################
            Write-Log -LogToWrite "---------------Processing Host $HostIP---------------"           

            if ($Global:cred) {
                Write-Host "Got credential from user! Invoking the copy command..." -ForegroundColor Green
                Invoke-CopyCommand -HostName "SingleHost" -HostIP $HostIP -SourcePath $SourcePath -TargetPath $TargetDir 
            }
        }
    }
    catch {
        Write-Error "Script failed out with error: $_" 
    }
}