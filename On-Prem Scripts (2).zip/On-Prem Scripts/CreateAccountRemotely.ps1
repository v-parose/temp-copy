<#
.SYNOPSIS
Create new user account on remote system(s)

.DESCRIPTION
Create a new user account with provided username, role, generate a password and store in provided KeyVault for remote system(s).

.PARAMETER PathForHostsFile
Use this together with MultiHosts to specify the .ini file that contains the hosts information. There could be multiple sections in one file.
Example:
    [Section1]
    CPPMAC-ARM64-01		ansible_host=10.250.123.8
    CPPMAC-ARM64-02		ansible_host=10.250.123.6
    [Section2]    
    CPPMAC-ARM64-01		ansible_host=10.250.123.8
    CPPMAC-ARM64-02		ansible_host=10.250.123.6

.PARAMETER MultiHosts
Use this to indicate running commands on multiple systems.
Use together with PathForHostsFile

.PARAMETER HostIP
Use this to pass the system IP when you would like to run commands on.

.PARAMETER UserName
Name of the new user to create.

.PARAMETER IsAdmin
True/False. Specify if the will be an Admin or not. 

.PARAMETER VaultName
Name of the Vault to store password for host(s). Ignore if no need to store. 
Script will prompt for user to sign in to access the Vault. Please make sure you have access to the KV when run this script.
#>
param(       
    # Hosts to crate account 
    [Parameter(mandatory = $false)]
    [string]
    $PathForHostsFile,
    # Indicate whether to process multi hosts    
    [Parameter(Mandatory = $false)]
    [switch]
    $MultiHosts,
    # Host to create account  
    [Parameter(Mandatory = $false)]    
    [string]
    $HostIP,
    [Parameter(Mandatory = $false)]
    [string]
    $UserName,    
    [Parameter(Mandatory = $false)]
    [bool]
    $IsAdmin,
    [parameter(Mandatory = $false)]
    [string]
    $VaultName
)

$ErrorActionPreference = 'Stop'
$failToImportModule = "Failed to import module files. Please make sure you have the Modules folder with following module files in same directory with this script and try again.`n ConsoleModule.psm1 `n FileModule.psm1 `n ProcessAnsibleInventoryFileModule.psm1 `n AzureModule.psm1"
try {
    Import-Module -Name $PSScriptRoot'\Modules\ProcessAnsibleInventoryFileModule.psm1' -Force
    Import-Module -Name $PSScriptRoot'\Modules\FileModule.psm1' -Force
    Import-Module -Name $PSScriptRoot'\Modules\ConsoleModule.psm1' -Force
    Import-Module -Name $PSScriptRoot'\Modules\AzureModule.psm1' -Force
}
catch {
    Write-Host $failToImportModule -ForegroundColor Red
    return
}

<#
.SYNOPSIS
Check and install or prompt on missing required dependencies
#>
function Import-RequiredModules {
    # Check if Posh-SSH is installed
    Write-Log -LogToWrite "Checking if Posh-SSH module is installed..."
    $poshSSHModule = "Posh-SSH"
    $installed = Get-Module -ListAvailable -Name $poshSSHModule   

    if ($null -eq $installed) {
        # If not installed, install Posh-SSH        
        # Write-Host "Posh-SSH module does not exist. Installing..." -ForegroundColor Magenta
        Write-Log -LogToWrite "Posh-SSH module does not exist. Installing..."
        try {
            Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
            Install-Module Posh-SSH -Force
            Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force
            # Write-Host "Posh-SSH successfully installed." -ForegroundColor Green
            Write-Log -LogToWrite "Posh-SSH successfully installed."
        }
        catch {
            Write-Log -LogToWrite "Failed to install moduel Posh-SSH with error: $($_.Exception)"
            Write-Error "Failed to install moduel Posh-SSH with error: $($_.Exception)"
        }
       
    }

    Write-Log -LogToWrite "All required modules have been installed!`n"
}

<#
.SYNOPSIS
Generate password with provided length with at least one digit, capital letter
Password is return in Secure string format
#>
function New-Password {
    param(
        [int]$Length
    )
    $chars = "23456789ABCDEFGHJKLMNPRSTUVWXYZabcdefghijkmnopqrstuvwxyz"    
    $caps = "ABCDEFGHJKLMNPRSTUVWXYZ"
    $digits = "23456789"
      
    $password = ""
    # At lease one digit, one capital letter
    $password += Get-Random -InputObject $digits.ToCharArray()
    $password += Get-Random -InputObject $caps.ToCharArray()    

    $leftCount = $Length - 2
    $password += -Join (Get-Random -InputObject $chars.ToCharArray() -Count $leftCount)

    ## Shuffle the result
    $fiPassword = -Join (Get-Random -InputObject $password.ToCharArray() -Count $Length)
    $securePassword = ConvertTo-SecureString $fiPassword -AsPlainText -Force

    return $securePassword
}

<#
.SYNOPSIS
Store/update the password to Azure KeyVault with host name as the secret name
#>
function Update-PasswordToAzure {
    param(
        [string]$HostName,
        [string]$VaultName,
        [securestring]$Password
    )
   
    if (Set-AzureSecret -KeyVault $VaultName -SecretName $HostName -SecretValue $Password) {
        Write-log -LogToWrite "Successfully update password for $HostName to Azure."
        Write-Host "Successfully update password for $HostName to Azure." -ForegroundColor Green         
    }
    else {
        Write-Log -LogToWrite "Error: Failed to update password for $HostName to Azure. Please try again later."
        Write-Host "Error: Failed to update password for $HostName to Azure. Please try again later." -ForegroundColor Red
    }
}

<#
.SYNOPSIS
Check if the remote path exist, if not create the path
#>
function Resolve-RemotePath {
    Param(
        $HostIP, #Single Host IP
        $Path
    )

    try {
        # Create SSHSession to run command remotely
        $session = New-SSHSession -ComputerName $HostIP -Credential $Global:Credential -Force
        $command = "mkdir -p $Path"
        $result = Invoke-SSHCommand -SSHSession $session -Command $command

        # Verify all hosts return 0        
        if ($result.ExitStatus -ne 0) {
            Write-Host "Failed to resolve path $Path on host $HostIP" -ForegroundColor Red  
            return $false          
        }

        return $true
    }
    catch {
        if ($($_.Exception).Message.ToLower() -like "*permission denied*") {
            Write-Host "Could not access the host $HostIP due to incorrect credential" -ForegroundColor Red
            Write-Log -LogToWrite "Could not access the host $HostIP due to incorrect credential"
        }
        Write-Host "Failed to resolve the path $Path on remote systems" -ForegroundColor Red
        return $false
    }
    finally {
        if ($session) {
            Remove-SSHSession $session | Out-Null
        }
    }
}

<#
.SYNOPSIS
Create a new user account with the script "On-Prem Scripts\CreateUserAccount.sh"
#>
function New-UserAccount {
    param(
        [Parameter(Mandatory = $true)]
        [string]
        $HostIP, # Single Host IP
        [Parameter(Mandatory = $true)]
        [string]
        $UserName,
        [Parameter(Mandatory = $true)]
        [securestring]
        $Password,
        [Parameter(Mandatory = $true)]
        [bool]
        $IsAdmin
    )

    try {
        ## copy script file to remote, then run script as sudo
        ## Copy https://stackoverflow.com/questions/73488837/windows-powershell-posh-ssh-module-script-sftp-file-upload-to-linux-server-givin
        $scriptPath = "CreateUserAccount.sh"
        $scriptFullPath = Resolve-Path $scriptPath
        $targetPath = "temp"

        
        if (Resolve-RemotePath $HostIP $targetPath) {
            # Upload script to remote host
            $CopyScriptSession = New-SFTPSession -ComputerName $HostIP -Credential $Global:Credential -Force
            if ($CopyScriptSession) {
                Set-SFTPItem -SFTPSession $CopyScriptSession -Path  $scriptFullPath -Destination $targetPath -Force

                ## Create SSHSession for running create user script     
                $session = New-SSHSession -ComputerName $HostIP -Credential $Global:Credential -Force
                
                if ($session) {
                    $passwordStr = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($Password))
                    $adminPwdStr = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($($Global:Credential).Password))
                    ## Change file mode to allow execute and Run command
                    $command = "chmod 755 $targetPath/$scriptPath ; vim $targetPath/$scriptPath -c 'set ff=unix' -c ':wq';  sudo $targetPath/$scriptPath -u $UserName -p $passwordStr -a $($IsAdmin.ToString().Tolower()) -m $(($Global:Credential).UserName) -t $adminPwdStr"
                    $result = Invoke-SSHCommand -SSHSession $session -Command $command

                    $result | ForEach-Object {
                        if (($result.ExitStatus -eq 1) -and ($result.Error -like "*sudo: a password is required*")) {
                            ## Failed to run the command due to sudo requires password per the the system configuration
                            ## Pipeline admin password and try again
                            $command = "chmod 755 $targetPath/$scriptPath ; vim $targetPath/$scriptPath -c 'set ff=unix' -c ':wq'; echo $adminPwdStr | sudo -S $targetPath/$scriptPath -u $UserName -p $passwordStr -a $($IsAdmin.ToString().Tolower()) -m $(($Global:Credential).UserName) -t $adminPwdStr"
                            $rel = Invoke-SSHCommand -SSHSession $session -Command $command
                            if (($rel.ExitStatus -eq 0) -and ($rel.Output -eq "succeeded")) {
                                Write-Host "Successfully created account $UserName on host $($_.Host).`n" -ForegroundColor Green
                                Write-log -LogToWrite "Successfully created account $UserName on host $($_.Host).`n"
                            }
                            else {
                                Write-Host "Failed to create account $UserName on host $($_.Host) with error $($_.Error)`n" -ForegroundColor Red
                                Write-log -LogToWrite "Failed to create account $UserName on host $($_.Host) with error $($_.Error)`n"
                            }
                        }
                        elseif ($_.ExitStatus -ne 0) {
                            Write-Host "Failed to create account $UserName on host $($_.Host) with error $($_.Error)`n" -ForegroundColor Red
                            Write-log -LogToWrite "Failed to create account $UserName on host $($_.Host) with error $($_.Error)`n"
                        }
                        elseif (($_.ExitStatus -eq 0) -and ($_.Output -eq "succeeded")) {
                            Write-Host "Successfully created account $UserName on host $($_.Host).`n" -ForegroundColor Green
                            Write-log -LogToWrite "Successfully created account $UserName on host $($_.Host).`n"
                        }
                    }
                }
            }
        }
        else {
            Write-Error "Failed to create account $UserName on host $HostIP due to could not copy script file to remote system(s)." -ErrorAction Continue
        }
    }
    catch {
        Write-Error "Failed to create account $UserName on host $HostIP due to error $($_.Exception)" -ErrorAction Continue
    }
    finally {
        if ($CopyScriptSession) {
            Remove-SFTPSession $CopyScriptSession | Out-Null
        }
        if ($session) {
            Remove-SSHSession $session | Out-Null
        }
        if ($passwordStr) {
            Remove-Variable passwordStr
        }
        if ($adminPwdStr) {
            Remove-Variable adminPwdStr
        }               
    }
}

try {
    Write-Log -LogToWrite "`n---------------Start the process for creating user account ---------------`n"
    Write-Log -LogToWrite "-------------------------Pre-Checking-------------------------"
    Import-RequiredModules
    ######################################################
    # Check parameters to make sure they are set properly
    ######################################################
    ## Host(s) information
    if (!($MultiHosts -and $PathForHostsFile) -and !($HostIP)) {
        Write-Log -LogToWrite "Get the host(s) to process"
        $title = 'Would you like to create user for multiple hosts?'
        $question = 'Yes for Multiple hosts, No for single host. Ctrl + C to cancel the process.'        
        $decision = Show-ConfirmMsg -Title $title -Content $question  
        if ($decision -eq 0) {
            $MultiHosts = $true            
            Write-Host "User would like to creat user for multiple hosts!" -ForegroundColor Green
            do {
                Write-Host "Please specify the path for a .ini file contains the hosts to process. Example: `n[VSM_XAM] `nVSM-XAM-10     ansible_host=10.218.200.24 `nVSM-XAM-11     ansible_host=10.218.200.26 `n" -ForegroundColor Cyan
                $PathForHostsFile = Read-Host "Enter the path for the .ini file contains hosts" 
            }while (!(Resolve-Path $PathForHostsFile -ErrorAction SilentlyContinue))   
            
            ## Prompt user to provide the credential to access the host(s) 
            Write-Host "Provide credential to connect to hosts" -ForegroundColor Cyan   
            $Global:Credential = Get-CredentialFromInput -UserNameMsg "Enter user name for connecting to hosts" -PasswordMsg "Enter password for connecting to hosts"
        }
        else {
            $MultiHosts = $false
            Write-Host "User would like to create user for single host!" -ForegroundColor Green            
            do {
                do {                   
                    $HostName = Read-Host "Enter the name for the host"
                }while (!$HostName.Trim())
                $HostName = $HostName.Trim()            
            
                do {                   
                    $HostIP = Read-Host "Enter the IP address for the host"
                }while (!$HostIP.Trim())
                $HostIP = $HostIP.Trim()
                ## Prompt user to provide the credential to access the host(s)    
                $Global:Credential = Get-CredentialFromInput -UserNameMsg "Enter user name for connecting to host $HostName"`
                    -PasswordMsg "Enter password for connecting to host $HostName"
            }while (!(Test-HostIP -HostName $HostName -HostIP $HostIP -Credential $Global:Credential))             
        }
    }

    ## User name
    do {
        Write-Log -LogToWrite "Trying to get name of the user account."    
        $UserName = Read-Host "Enter the name of the User to create"    
    }while (!$UserName.Trim())

    Write-Log -LogToWrite "Name of the user account is $UserName"

    ## Is Admin user
    $title = 'Is the user going to be an Admin?'
    $question = 'Yes for Admin user, No for normal user. Ctrl + C to cancel the process.'        
    $decision = Show-ConfirmMsg -Title $title -Content $question
    if ($decision -eq 0) {
        $IsAdmin = $true
    }
    else {       
        $IsAdmin = $false
    }    
  
    Write-Log -LogToWrite "Will the user be an Admin: $IsAdmin"    

    ## Prompt for user to type and confirm password 
    $title = 'Would you like to let the script generate password for each host or enter one password for all?'
    $question = 'Yes for generating password. No for enter password manually. Ctrl + C to cancel the process.'        
    $decision = Show-ConfirmMsg -Title $title -Content $question
    if ($decision -eq 0) {
        Write-Log -LogToWrite "The script will generate password for each host"
        Write-Host "The script will generate password for each host" -ForegroundColor Cyan        
    }  
    else {
        Write-Log -LogToWrite "User choose to enter password manually"
        do {    
            $ManualPassword = Read-Host "Enter the password for the user" -AsSecureString
            $ConfirmPwd = Read-Host "Retype to confirm the password" -AsSecureString
            $PasswordStr = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($ManualPassword))
            $ConfirmPwdStr = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($ConfirmPwd))
        }
        while ($PasswordStr -ne $ConfirmPwdStr)

        if ($PasswordStr) { Remove-Variable PasswordStr }
        if ($ConfirmPwdStr) { Remove-Variable ConfirmPwdStr }
        if ($ConfirmPwd) { Remove-Variable ConfirmPwd } 
    }        

    ## Signin to Azure so we could use this to update keyvault    
    Write-Host "Provide the Vault name to store the password for the new user account for host(s)" -ForegroundColor Cyan
    $VaultName = Read-Host "Enter the Vault name (Press Enter directly if no need to store the password)"
    # Trim the spaces in case user copys extra spaces from web UI
    $VaultName = $VaultName.Trim()
    if ($VaultName) {
        Write-Host "Login to Azure to provide permission to update new password to Azure KeyVault $VaultName" -ForegroundColor Cyan
        Connect-AzAccount  -DeviceCode | Out-Null
    }
    
    #####################################################################
    ## Start process
    #####################################################################
    if ($MultiHosts) {
        ################################################################################
        # Process with multiple hosts
        ################################################################################  
        Write-Log -LogToWrite "Processing multi hosts."    
        $hosts = Get-HostsToProcess -PathForHostsFile $PathForHostsFile

        # Print out the hosts list for user to confirm
        Write-Log -LogToWrite "Hosts retrieved from inventory file:"
        foreach ($key in $hosts.Keys) {            
            Write-Log -LogToWrite "    Found $($($($hosts.Item($key)).Keys).Count) hosts for $key"
            Write-Host "Found $($($($hosts.Item($key)).Keys).Count) hosts for $key" -ForegroundColor Green
        }

        $title = 'Confirm to process hosts'
        $question = 'Would you like to continue to process the hosts?'        
        $decision = Show-ConfirmMsg -Title $title -Content $question
        if ($decision -eq 0) {
            Write-Host "User would like to continue the process" -ForegroundColor Green

            foreach ($key in $hosts.Keys) {
                Write-Log -LogToWrite "---------------Processing hosts for $key---------------"
                Write-Host "`n--------------Procession hosts for $key--------------`n" -ForegroundColor Cyan
                $hostsForSection = $hosts.Item($key)

                $hostNames = $hostsForSection.Keys
                if ($hostNames.Count -gt 0) {
                    foreach ($hostName in $hostNames) {
                        # Process each host
                        $hostIP = $hostsForSection.Item($hostName)

                        # Verify host name and IP are match
                        $rel = Test-HostIP -HostName $hostName -HostIP $hostIP -Credential $Global:Credential
                        If ($rel) {
                        
                            Write-Log -LogToWrite "Creating user $UserName for $hostName ($hostIP)"
                            Write-Host "-----Creating user $UserName for $hostName ($hostIP)-----" -ForegroundColor Cyan
                        
                            if ($ManualPassword) {
                                $password = $ManualPassword                           
                            }
                            else {
                                # Generate password for the host
                                $password = New-Password -Length 12
                            }
                            # Create user with the generated password
                            New-UserAccount -HostIP $hostIP -UserName $UserName -Password $password -IsAdmin $IsAdmin

                            if ($VaultName) {
                                # Save the password to KeyVault
                                Update-PasswordToAzure -HostName $hostName -VaultName $VaultName -Password $password
                            }
                            Write-Log -LogToWrite "Completed user creation for $hostName ($hostIP)`n"
                            Write-Host "Completed user creation for $hostName ($hostIP)`n" -ForegroundColor Green
                        }  
                        elseif($rel -eq $false){
                            Write-Log -LogToWrite "The host name and IP for $HostName do not match. Skipped."
                            Write-Host "The host name and IP for $HostName do not match. Skipped." -ForegroundColor Red
                        }                 
                    }
                }   
            }  
        }  
    }
    else {
        ################################################################################
        # Process single host
        ################################################################################ 
        Write-Log -LogToWrite "-------------------------------Processing host $HostName($HostIP)------------------------------"
        Write-Log -LogToWrite "Creating user $UserName for $HostName($HostIP)"
        Write-Host "-----Creating user $UserName for $HostName($HostIP)-----" -ForegroundColor Cyan
        
        if ($ManualPassword) {
            $password = $ManualPassword                           
        }
        else {
            # Generate password for the host
            $password = New-Password -Length 12
        }

        # Create user with the generated password
        New-UserAccount -HostIP $HostIP -UserName $UserName -Password $password -IsAdmin $IsAdmin

        if ($VaultName) {
            # Save the password to KeyVault
            Update-PasswordToAzure -HostName $HostName -VaultName $VaultName -Password $password
        }  
        
        Write-Log -LogToWrite "Completed user creation."
    }
}
catch {
    Write-Error "Script failed with error: $_"
}